package com.merchantpay.chargeback.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Request payload for creating a new chargeback case.
 */
public record CreateChargebackCaseRequest(
        @NotNull Long txnId,
        @NotNull Long merchantId,
        @NotBlank String reasonCode,
        BigDecimal claimAmount,
        LocalDate responseDeadline
) {}
