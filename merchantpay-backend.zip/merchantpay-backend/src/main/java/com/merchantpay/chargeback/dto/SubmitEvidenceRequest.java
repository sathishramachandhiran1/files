package com.merchantpay.chargeback.dto;

import com.merchantpay.common.enums.Enums.EvidenceType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

/**
 * Request payload for submitting a piece of evidence against a chargeback case.
 */
public record SubmitEvidenceRequest(
        @NotNull EvidenceType evidenceType,
        @NotBlank String filePath
) {}
