package com.merchantpay.chargeback.repository;

import com.merchantpay.chargeback.domain.DisputeEvidence;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Spring Data repository for {@link DisputeEvidence} entities.
 */
public interface DisputeEvidenceRepository extends JpaRepository<DisputeEvidence, Long> {

    Page<DisputeEvidence> findByCaseId(Long caseId, Pageable pageable);

    boolean existsByCaseId(Long caseId);
}
