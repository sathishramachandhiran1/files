package com.merchantpay.chargeback.dto;

import com.merchantpay.common.enums.Enums.ChargebackStatus;
import jakarta.validation.constraints.NotNull;

/**
 * Request payload for resolving a chargeback case with a terminal outcome.
 * The {@code status} must be one of {@code WON}, {@code LOST}, or {@code REVERSED}.
 */
public record ResolveCaseRequest(
        @NotNull ChargebackStatus status
) {}
