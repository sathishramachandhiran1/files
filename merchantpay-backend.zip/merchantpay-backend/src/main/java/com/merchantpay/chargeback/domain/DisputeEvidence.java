package com.merchantpay.chargeback.domain;

import com.merchantpay.common.domain.BaseEntity;
import com.merchantpay.common.enums.Enums.EvidenceStatus;
import com.merchantpay.common.enums.Enums.EvidenceType;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

/**
 * A piece of supporting evidence submitted against a {@link ChargebackCase}.
 */
@Entity
@Table(name = "dispute_evidence", indexes = {
        @Index(name = "idx_dispute_evidence_case_id", columnList = "case_id")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DisputeEvidence extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "evidence_id")
    private Long evidenceId;

    @Column(name = "case_id", nullable = false)
    private Long caseId;

    @Enumerated(EnumType.STRING)
    @Column(name = "evidence_type", nullable = false, length = 32)
    private EvidenceType evidenceType;

    @Column(name = "file_path", nullable = false)
    private String filePath;

    @Column(name = "uploaded_date")
    @Builder.Default
    private LocalDate uploadedDate = LocalDate.now();

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 16)
    @Builder.Default
    private EvidenceStatus status = EvidenceStatus.SUBMITTED;

    @PrePersist
    void defaultDates() {
        if (uploadedDate == null) {
            uploadedDate = LocalDate.now();
        }
    }
}
