package com.merchantpay.chargeback.dto;

import com.merchantpay.chargeback.domain.ChargebackCase;
import com.merchantpay.common.enums.Enums.ChargebackStatus;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Read model returned for a {@link ChargebackCase}.
 */
public record ChargebackCaseResponse(
        Long caseId,
        Long txnId,
        Long merchantId,
        String reasonCode,
        BigDecimal claimAmount,
        LocalDate receivedDate,
        LocalDate responseDeadline,
        Long assignedAnalystId,
        ChargebackStatus status
) {
    public static ChargebackCaseResponse from(ChargebackCase c) {
        return new ChargebackCaseResponse(
                c.getCaseId(),
                c.getTxnId(),
                c.getMerchantId(),
                c.getReasonCode(),
                c.getClaimAmount(),
                c.getReceivedDate(),
                c.getResponseDeadline(),
                c.getAssignedAnalystId(),
                c.getStatus()
        );
    }
}
