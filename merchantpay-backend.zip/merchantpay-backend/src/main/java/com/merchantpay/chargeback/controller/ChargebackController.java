package com.merchantpay.chargeback.controller;

import com.merchantpay.chargeback.dto.*;
import com.merchantpay.chargeback.service.ChargebackService;
import com.merchantpay.common.enums.Enums.ChargebackStatus;
import com.merchantpay.common.web.PageResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * Chargeback case intake, lifecycle transitions, and evidence management endpoints.
 */
@RestController
@RequestMapping
@RequiredArgsConstructor
@Tag(name = "Chargeback & Dispute Management", description = "Chargeback cases, analyst assignment, and dispute evidence")
public class ChargebackController {

    private final ChargebackService chargebackService;

    // ---- Cases ----

    @PostMapping("/chargeback-cases")
    @PreAuthorize("hasAnyRole('DISPUTE_ANALYST','ADMIN')")
    @Operation(summary = "Create a new chargeback case")
    public ResponseEntity<ChargebackCaseResponse> createCase(@Valid @RequestBody CreateChargebackCaseRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(chargebackService.createCase(req));
    }

    @GetMapping("/chargeback-cases")
    @PreAuthorize("hasAnyRole('DISPUTE_ANALYST','ADMIN') or (hasRole('MERCHANT') and #merchantId == authentication.principal.merchantId)")
    @Operation(summary = "List chargeback cases, optionally filtered by merchantId, status, or assignedAnalystId")
    public PageResponse<ChargebackCaseResponse> listCases(
            @RequestParam(required = false) Long merchantId,
            @RequestParam(required = false) ChargebackStatus status,
            @RequestParam(required = false) Long assignedAnalystId,
            Pageable pageable) {
        return PageResponse.from(chargebackService.listCases(merchantId, status, assignedAnalystId, pageable), c -> c);
    }

    @GetMapping("/chargeback-cases/{caseId}")
    @PreAuthorize("hasAnyRole('DISPUTE_ANALYST','ADMIN')")
    @Operation(summary = "Get a chargeback case by id")
    public ChargebackCaseResponse getCase(@PathVariable Long caseId) {
        return chargebackService.getCase(caseId);
    }

    @PostMapping("/chargeback-cases/{caseId}/request-documents")
    @PreAuthorize("hasAnyRole('DISPUTE_ANALYST','ADMIN')")
    @Operation(summary = "Transition a case from RECEIVED to DOCUMENTS_REQUESTED")
    public ChargebackCaseResponse requestDocuments(@PathVariable Long caseId) {
        return chargebackService.requestDocuments(caseId);
    }

    @PostMapping("/chargeback-cases/{caseId}/assign")
    @PreAuthorize("hasAnyRole('DISPUTE_ANALYST','ADMIN')")
    @Operation(summary = "Assign a dispute analyst to a chargeback case")
    public ChargebackCaseResponse assignCase(@PathVariable Long caseId,
                                             @Valid @RequestBody AssignCaseRequest req) {
        return chargebackService.assignCase(caseId, req);
    }

    @PostMapping("/chargeback-cases/{caseId}/resolve")
    @PreAuthorize("hasAnyRole('DISPUTE_ANALYST','ADMIN')")
    @Operation(summary = "Resolve a chargeback case as WON, LOST, or REVERSED")
    public ChargebackCaseResponse resolveCase(@PathVariable Long caseId,
                                              @Valid @RequestBody ResolveCaseRequest req) {
        return chargebackService.resolveCase(caseId, req);
    }

    // ---- Evidence ----

    @PostMapping("/chargeback-cases/{caseId}/evidence")
    @PreAuthorize("hasAnyRole('DISPUTE_ANALYST','ADMIN')")
    @Operation(summary = "Submit a piece of evidence for a chargeback case")
    public ResponseEntity<DisputeEvidenceResponse> submitEvidence(@PathVariable Long caseId,
                                                                   @Valid @RequestBody SubmitEvidenceRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(chargebackService.submitEvidence(caseId, req));
    }

    @GetMapping("/chargeback-cases/{caseId}/evidence")
    @PreAuthorize("hasAnyRole('DISPUTE_ANALYST','ADMIN')")
    @Operation(summary = "List all evidence submitted for a chargeback case")
    public PageResponse<DisputeEvidenceResponse> listEvidence(@PathVariable Long caseId, Pageable pageable) {
        return PageResponse.from(chargebackService.listEvidence(caseId, pageable), e -> e);
    }

    @PatchMapping("/evidence/{evidenceId}")
    @PreAuthorize("hasAnyRole('DISPUTE_ANALYST','ADMIN')")
    @Operation(summary = "Update the review status of a piece of dispute evidence")
    public DisputeEvidenceResponse updateEvidenceStatus(@PathVariable Long evidenceId,
                                                         @Valid @RequestBody UpdateEvidenceStatusRequest req) {
        return chargebackService.updateEvidenceStatus(evidenceId, req);
    }
}
