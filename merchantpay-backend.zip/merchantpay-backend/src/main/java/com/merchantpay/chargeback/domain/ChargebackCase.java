package com.merchantpay.chargeback.domain;

import com.merchantpay.common.domain.BaseEntity;
import com.merchantpay.common.enums.Enums.ChargebackStatus;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Represents a chargeback case raised against a merchant transaction.
 */
@Entity
@Table(name = "chargeback_case", indexes = {
        @Index(name = "idx_chargeback_case_merchant_id", columnList = "merchant_id"),
        @Index(name = "idx_chargeback_case_txn_id", columnList = "txn_id")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ChargebackCase extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "case_id")
    private Long caseId;

    @Column(name = "txn_id", nullable = false)
    private Long txnId;

    @Column(name = "merchant_id", nullable = false)
    private Long merchantId;

    @Column(name = "reason_code", nullable = false)
    private String reasonCode;

    @Column(name = "claim_amount", precision = 19, scale = 4)
    private BigDecimal claimAmount;

    @Column(name = "received_date")
    @Builder.Default
    private LocalDate receivedDate = LocalDate.now();

    @Column(name = "response_deadline")
    private LocalDate responseDeadline;

    @Column(name = "assigned_analyst_id")
    private Long assignedAnalystId;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 24)
    @Builder.Default
    private ChargebackStatus status = ChargebackStatus.RECEIVED;

    @PrePersist
    void defaultDates() {
        if (receivedDate == null) {
            receivedDate = LocalDate.now();
        }
        if (responseDeadline == null) {
            responseDeadline = receivedDate.plusDays(30);
        }
    }
}
