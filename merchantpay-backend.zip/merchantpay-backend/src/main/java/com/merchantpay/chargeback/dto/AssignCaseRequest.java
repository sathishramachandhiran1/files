package com.merchantpay.chargeback.dto;

import jakarta.validation.constraints.NotNull;

/**
 * Request payload for assigning a dispute analyst to a chargeback case.
 */
public record AssignCaseRequest(
        @NotNull Long analystId
) {}
