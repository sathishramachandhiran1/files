package com.merchantpay.chargeback.dto;

import com.merchantpay.common.enums.Enums.EvidenceStatus;
import jakarta.validation.constraints.NotNull;

/**
 * Request payload for updating the review status of a piece of dispute evidence.
 */
public record UpdateEvidenceStatusRequest(
        @NotNull EvidenceStatus status
) {}
