package com.merchantpay.chargeback.repository;

import com.merchantpay.chargeback.domain.ChargebackCase;
import com.merchantpay.common.enums.Enums.ChargebackStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Spring Data repository for {@link ChargebackCase} entities.
 */
public interface ChargebackCaseRepository extends JpaRepository<ChargebackCase, Long> {

    Page<ChargebackCase> findByMerchantId(Long merchantId, Pageable pageable);

    Page<ChargebackCase> findByStatus(ChargebackStatus status, Pageable pageable);

    Page<ChargebackCase> findByMerchantIdAndStatus(Long merchantId, ChargebackStatus status, Pageable pageable);

    Page<ChargebackCase> findByAssignedAnalystId(Long assignedAnalystId, Pageable pageable);

    Page<ChargebackCase> findByMerchantIdAndAssignedAnalystId(Long merchantId, Long assignedAnalystId, Pageable pageable);

    Page<ChargebackCase> findByStatusAndAssignedAnalystId(ChargebackStatus status, Long assignedAnalystId, Pageable pageable);

    Page<ChargebackCase> findByMerchantIdAndStatusAndAssignedAnalystId(Long merchantId, ChargebackStatus status,
                                                                        Long assignedAnalystId, Pageable pageable);
}
