package com.merchantpay.chargeback.dto;

import com.merchantpay.chargeback.domain.DisputeEvidence;
import com.merchantpay.common.enums.Enums.EvidenceStatus;
import com.merchantpay.common.enums.Enums.EvidenceType;

import java.time.LocalDate;

/**
 * Read model returned for a {@link DisputeEvidence} record.
 */
public record DisputeEvidenceResponse(
        Long evidenceId,
        Long caseId,
        EvidenceType evidenceType,
        String filePath,
        LocalDate uploadedDate,
        EvidenceStatus status
) {
    public static DisputeEvidenceResponse from(DisputeEvidence e) {
        return new DisputeEvidenceResponse(
                e.getEvidenceId(),
                e.getCaseId(),
                e.getEvidenceType(),
                e.getFilePath(),
                e.getUploadedDate(),
                e.getStatus()
        );
    }
}
