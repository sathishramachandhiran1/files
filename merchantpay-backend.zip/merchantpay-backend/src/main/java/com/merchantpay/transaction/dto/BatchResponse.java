package com.merchantpay.transaction.dto;

import com.merchantpay.common.enums.Enums.BatchStatus;
import com.merchantpay.transaction.domain.TransactionBatch;
import lombok.Builder;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Read model for a {@link TransactionBatch}.
 */
@Builder
public record BatchResponse(
        Long batchId,
        Long merchantId,
        Long terminalId,
        LocalDate batchDate,
        int totalTransactions,
        BigDecimal totalAmount,
        BatchStatus status
) {
    public static BatchResponse from(TransactionBatch b) {
        return BatchResponse.builder()
                .batchId(b.getBatchId())
                .merchantId(b.getMerchantId())
                .terminalId(b.getTerminalId())
                .batchDate(b.getBatchDate())
                .totalTransactions(b.getTotalTransactions())
                .totalAmount(b.getTotalAmount())
                .status(b.getStatus())
                .build();
    }
}
