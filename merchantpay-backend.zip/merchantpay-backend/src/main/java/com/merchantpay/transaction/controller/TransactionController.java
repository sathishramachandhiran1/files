package com.merchantpay.transaction.controller;

import com.merchantpay.common.enums.Enums.BatchStatus;
import com.merchantpay.common.enums.Enums.TransactionStatus;
import com.merchantpay.common.web.PageResponse;
import com.merchantpay.transaction.dto.*;
import com.merchantpay.transaction.service.TransactionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * Transaction processing endpoints: record, query, and lifecycle transitions for
 * payment transactions and settlement batches.
 */
@RestController
@RequestMapping
@RequiredArgsConstructor
@Tag(name = "Transaction Processing & Authorisation", description = "Payment transactions and settlement batches")
public class TransactionController {

    private final TransactionService transactionService;

    // ---- Transactions ----

    @PostMapping("/transactions")
    @PreAuthorize("hasAnyRole('ACQ_OPS','ADMIN')")
    @Operation(summary = "Record a new payment transaction")
    public ResponseEntity<TransactionResponse> createTransaction(@Valid @RequestBody CreateTransactionRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(transactionService.createTransaction(req));
    }

    @GetMapping("/transactions")
    @PreAuthorize("hasAnyRole('ACQ_OPS','ADMIN') or (hasRole('MERCHANT') and #merchantId == authentication.principal.merchantId)")
    @Operation(summary = "List transactions with optional merchantId and status filters")
    public PageResponse<TransactionResponse> listTransactions(
            @RequestParam(required = false) Long merchantId,
            @RequestParam(required = false) TransactionStatus status,
            Pageable pageable) {
        return PageResponse.from(transactionService.listTransactions(merchantId, status, pageable), t -> t);
    }

    @GetMapping("/transactions/{txnId}")
    @PreAuthorize("hasAnyRole('ACQ_OPS','ADMIN') or (hasRole('MERCHANT') and #merchantId == authentication.principal.merchantId)")
    @Operation(summary = "Get a single payment transaction by id")
    public TransactionResponse getTransaction(@PathVariable Long txnId) {
        return transactionService.getTransaction(txnId);
    }

    @PostMapping("/transactions/{txnId}/capture")
    @PreAuthorize("hasAnyRole('ACQ_OPS','ADMIN')")
    @Operation(summary = "Capture an AUTHORISED transaction")
    public TransactionResponse captureTransaction(@PathVariable Long txnId) {
        return transactionService.captureTransaction(txnId);
    }

    @PostMapping("/transactions/{txnId}/void")
    @PreAuthorize("hasAnyRole('ACQ_OPS','ADMIN')")
    @Operation(summary = "Void an AUTHORISED or PENDING transaction")
    public TransactionResponse voidTransaction(@PathVariable Long txnId) {
        return transactionService.voidTransaction(txnId);
    }

    @PostMapping("/transactions/{txnId}/refund")
    @PreAuthorize("hasAnyRole('ACQ_OPS','ADMIN')")
    @Operation(summary = "Refund a CAPTURED transaction")
    public TransactionResponse refundTransaction(@PathVariable Long txnId) {
        return transactionService.refundTransaction(txnId);
    }

    // ---- Batches ----

    @PostMapping("/batches")
    @PreAuthorize("hasAnyRole('ACQ_OPS','ADMIN')")
    @Operation(summary = "Open a new transaction batch for a merchant terminal")
    public ResponseEntity<BatchResponse> createBatch(@Valid @RequestBody CreateBatchRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(transactionService.createBatch(req));
    }

    @GetMapping("/batches")
    @PreAuthorize("hasAnyRole('ACQ_OPS','ADMIN') or (hasRole('MERCHANT') and #merchantId == authentication.principal.merchantId)")
    @Operation(summary = "List batches with optional merchantId and status filters")
    public PageResponse<BatchResponse> listBatches(
            @RequestParam(required = false) Long merchantId,
            @RequestParam(required = false) BatchStatus status,
            Pageable pageable) {
        return PageResponse.from(transactionService.listBatches(merchantId, status, pageable), b -> b);
    }

    @GetMapping("/batches/{batchId}")
    @PreAuthorize("hasAnyRole('ACQ_OPS','ADMIN')")
    @Operation(summary = "Get a single batch by id")
    public BatchResponse getBatch(@PathVariable Long batchId) {
        return transactionService.getBatch(batchId);
    }

    @PostMapping("/batches/{batchId}/close")
    @PreAuthorize("hasAnyRole('ACQ_OPS','ADMIN')")
    @Operation(summary = "Close an OPEN batch")
    public BatchResponse closeBatch(@PathVariable Long batchId) {
        return transactionService.closeBatch(batchId);
    }

    @PostMapping("/batches/{batchId}/submit")
    @PreAuthorize("hasAnyRole('ACQ_OPS','ADMIN')")
    @Operation(summary = "Submit a CLOSED batch for settlement")
    public BatchResponse submitBatch(@PathVariable Long batchId) {
        return transactionService.submitBatch(batchId);
    }
}
