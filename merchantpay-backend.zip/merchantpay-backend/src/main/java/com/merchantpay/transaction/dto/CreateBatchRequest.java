package com.merchantpay.transaction.dto;

import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;

/**
 * Request payload for opening a new transaction batch.
 */
public record CreateBatchRequest(

        @NotNull
        Long merchantId,

        Long terminalId,

        /** Batch date; defaults to today when not supplied. */
        LocalDate batchDate
) {
}
