package com.merchantpay.transaction.domain;

import com.merchantpay.common.domain.BaseEntity;
import com.merchantpay.common.enums.Enums.BatchStatus;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Groups payment transactions into a single reconciliation batch for a merchant terminal.
 */
@Entity
@Table(
        name = "transaction_batch",
        indexes = {
                @Index(name = "idx_tb_merchant_id", columnList = "merchant_id")
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransactionBatch extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "batch_id")
    private Long batchId;

    @Column(name = "merchant_id", nullable = false)
    private Long merchantId;

    @Column(name = "terminal_id")
    private Long terminalId;

    @Column(name = "batch_date")
    @Builder.Default
    private LocalDate batchDate = LocalDate.now();

    @Column(name = "total_transactions")
    @Builder.Default
    private int totalTransactions = 0;

    @Column(name = "total_amount", precision = 19, scale = 4)
    @Builder.Default
    private BigDecimal totalAmount = BigDecimal.ZERO;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 16)
    @Builder.Default
    private BatchStatus status = BatchStatus.OPEN;

    @PrePersist
    private void prePersist() {
        if (batchDate == null) {
            batchDate = LocalDate.now();
        }
        if (totalAmount == null) {
            totalAmount = BigDecimal.ZERO;
        }
        if (status == null) {
            status = BatchStatus.OPEN;
        }
    }
}
