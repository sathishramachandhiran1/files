package com.merchantpay.transaction.dto;

import com.merchantpay.common.enums.Enums.PaymentChannel;
import com.merchantpay.common.enums.Enums.TransactionStatus;
import com.merchantpay.common.enums.Enums.TransactionType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;

/**
 * Request payload for recording a new payment transaction.
 * Only the card BIN (up to 6 digits) may be supplied — never a full PAN.
 */
public record CreateTransactionRequest(

        @NotNull
        Long merchantId,

        Long terminalId,

        @NotNull
        PaymentChannel paymentChannel,

        @NotNull
        TransactionType transactionType,

        @NotNull
        @Positive
        BigDecimal amount,

        @Size(min = 3, max = 3)
        String currency,

        /** First 6 digits of the card PAN only. */
        @Size(max = 6)
        String cardBin,

        String authorisationCode,

        /** Initial status; defaults to PENDING when not supplied. */
        TransactionStatus status
) {
}
