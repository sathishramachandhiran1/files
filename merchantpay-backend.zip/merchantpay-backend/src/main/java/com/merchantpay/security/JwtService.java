package com.merchantpay.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.util.Base64;
import java.util.Date;
import java.util.Map;

@Service
public class JwtService {

    private final SecretKey signingKey;
    private final long accessTtlSeconds;

    public JwtService(
            @Value("${app.security.jwt.secret}") String secret,
            @Value("${app.security.jwt.access-token-validity-seconds}") long accessTtlSeconds) {
        this.signingKey = Keys.hmacShaKeyFor(Base64.getDecoder().decode(secret));
        this.accessTtlSeconds = accessTtlSeconds;
    }

    public String generateAccessToken(AppUserPrincipal principal) {
        Date now = new Date();
        return Jwts.builder()
                .claims(Map.of(
                        "uid", principal.getUserId(),
                        "role", principal.getAuthorities().iterator().next().getAuthority(),
                        "mid", principal.getMerchantId() == null ? -1 : principal.getMerchantId()
                ))
                .subject(principal.getUsername())
                .issuedAt(now)
                .expiration(new Date(now.getTime() + accessTtlSeconds * 1000))
                .signWith(signingKey)
                .compact();
    }

    public String extractUsername(String token) {
        return parse(token).getSubject();
    }

    public boolean isValid(String token, AppUserPrincipal principal) {
        try {
            Claims claims = parse(token);
            return claims.getSubject().equals(principal.getUsername()) && claims.getExpiration().after(new Date());
        } catch (Exception e) {
            return false;
        }
    }

    private Claims parse(String token) {
        return Jwts.parser().verifyWith(signingKey).build().parseSignedClaims(token).getPayload();
    }
}