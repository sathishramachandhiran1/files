package com.merchantpay.onboarding.dto;

import com.merchantpay.common.enums.Enums.DocumentType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record KybDocumentRequest(
        @NotNull DocumentType documentType,
        @NotBlank String filePath
) {
}
