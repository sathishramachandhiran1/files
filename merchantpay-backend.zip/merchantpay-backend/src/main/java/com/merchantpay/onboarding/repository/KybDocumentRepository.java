package com.merchantpay.onboarding.repository;

import com.merchantpay.onboarding.domain.KybDocument;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface KybDocumentRepository extends JpaRepository<KybDocument, Long> {

    Page<KybDocument> findByMerchantId(Long merchantId, Pageable pageable);
}
