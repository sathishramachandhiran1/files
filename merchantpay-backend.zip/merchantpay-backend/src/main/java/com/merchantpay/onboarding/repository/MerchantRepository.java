package com.merchantpay.onboarding.repository;

import com.merchantpay.common.enums.Enums.MerchantStatus;
import com.merchantpay.onboarding.domain.Merchant;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MerchantRepository extends JpaRepository<Merchant, Long> {

    Page<Merchant> findByStatus(MerchantStatus status, Pageable pageable);

    boolean existsByMerchantCode(String merchantCode);
}
