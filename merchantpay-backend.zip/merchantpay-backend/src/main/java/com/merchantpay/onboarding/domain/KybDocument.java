package com.merchantpay.onboarding.domain;

import com.merchantpay.common.domain.BaseEntity;
import com.merchantpay.common.enums.Enums.DocumentType;
import com.merchantpay.common.enums.Enums.VerificationStatus;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

/**
 * A KYB verification document uploaded for a merchant.
 */
@Entity
@Table(name = "kyb_document", indexes = @Index(name = "idx_kyb_merchant", columnList = "merchant_id"))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class KybDocument extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "doc_id")
    private Long docId;

    @Column(name = "merchant_id", nullable = false)
    private Long merchantId;

    @Enumerated(EnumType.STRING)
    @Column(name = "document_type", nullable = false, length = 32)
    private DocumentType documentType;

    @Column(name = "file_path", nullable = false)
    private String filePath;

    @Column(name = "uploaded_date", nullable = false)
    private LocalDate uploadedDate;

    @Enumerated(EnumType.STRING)
    @Column(name = "verification_status", nullable = false, length = 16)
    @Builder.Default
    private VerificationStatus verificationStatus = VerificationStatus.PENDING;

    @PrePersist
    void onCreate() {
        if (uploadedDate == null) {
            uploadedDate = LocalDate.now();
        }
    }
}
