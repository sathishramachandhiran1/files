package com.merchantpay.onboarding.domain;

import com.merchantpay.common.domain.BaseEntity;
import com.merchantpay.common.enums.Enums.ApplicationStatus;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

/**
 * A merchant's application to be onboarded; progresses through KYB to activation.
 */
@Entity
@Table(name = "merchant_application", uniqueConstraints = {
        @UniqueConstraint(name = "uk_app_registration", columnNames = "registration_number")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MerchantApplication extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "app_id")
    private Long appId;

    @Column(name = "business_name", nullable = false)
    private String businessName;

    @Column(name = "registration_number", nullable = false)
    private String registrationNumber;

    @Column(length = 8)
    private String mcc;

    @Column(name = "business_type")
    private String businessType;

    @Column(name = "owner_name")
    private String ownerName;

    @Column(name = "national_id_ref")
    private String nationalIdRef;

    @Column(name = "settlement_bank_account_ref")
    private String settlementBankAccountRef;

    /** Tracks which user (APPLICANT or staff) submitted this application. */
    @Column(name = "submitted_by_user_id")
    private Long submittedByUserId;

    @Column(name = "application_date", nullable = false)
    private LocalDate applicationDate;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 24)
    @Builder.Default
    private ApplicationStatus status = ApplicationStatus.SUBMITTED;

    @PrePersist
    void onCreate() {
        if (applicationDate == null) {
            applicationDate = LocalDate.now();
        }
    }
}
