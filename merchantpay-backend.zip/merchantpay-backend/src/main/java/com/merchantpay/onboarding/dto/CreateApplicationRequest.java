package com.merchantpay.onboarding.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record CreateApplicationRequest(
        @NotBlank String businessName,
        @NotBlank String registrationNumber,
        @Size(max = 8) String mcc,
        String businessType,
        String ownerName,
        String nationalIdRef,
        String settlementBankAccountRef
) {
}
