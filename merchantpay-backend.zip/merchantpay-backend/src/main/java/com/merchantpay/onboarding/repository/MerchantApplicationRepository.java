package com.merchantpay.onboarding.repository;

import com.merchantpay.common.enums.Enums.ApplicationStatus;
import com.merchantpay.onboarding.domain.MerchantApplication;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MerchantApplicationRepository extends JpaRepository<MerchantApplication, Long> {

    Page<MerchantApplication> findByStatus(ApplicationStatus status, Pageable pageable);

    boolean existsByRegistrationNumber(String registrationNumber);

    // APPLICANT-scoped queries — only returns applications submitted by that user
    Page<MerchantApplication> findBySubmittedByUserId(Long submittedByUserId, Pageable pageable);

    Page<MerchantApplication> findBySubmittedByUserIdAndStatus(Long submittedByUserId, ApplicationStatus status, Pageable pageable);
}
