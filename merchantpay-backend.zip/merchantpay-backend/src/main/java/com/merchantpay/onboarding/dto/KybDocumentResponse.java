package com.merchantpay.onboarding.dto;

import com.merchantpay.common.enums.Enums.DocumentType;
import com.merchantpay.common.enums.Enums.VerificationStatus;
import com.merchantpay.onboarding.domain.KybDocument;

import java.time.LocalDate;

public record KybDocumentResponse(
        Long docId,
        Long merchantId,
        DocumentType documentType,
        String filePath,
        LocalDate uploadedDate,
        VerificationStatus verificationStatus
) {
    public static KybDocumentResponse from(KybDocument d) {
        return new KybDocumentResponse(d.getDocId(), d.getMerchantId(), d.getDocumentType(),
                d.getFilePath(), d.getUploadedDate(), d.getVerificationStatus());
    }
}
