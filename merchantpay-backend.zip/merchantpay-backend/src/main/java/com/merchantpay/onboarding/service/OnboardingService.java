package com.merchantpay.onboarding.service;

import com.merchantpay.common.enums.Enums.*;
import com.merchantpay.common.exception.BusinessRuleException;
import com.merchantpay.common.exception.DuplicateResourceException;
import com.merchantpay.common.exception.ResourceNotFoundException;
import com.merchantpay.iam.service.AuditService;
import com.merchantpay.onboarding.domain.KybDocument;
import com.merchantpay.onboarding.domain.Merchant;
import com.merchantpay.onboarding.domain.MerchantApplication;
import com.merchantpay.onboarding.dto.*;
import com.merchantpay.onboarding.repository.KybDocumentRepository;
import com.merchantpay.onboarding.repository.MerchantApplicationRepository;
import com.merchantpay.onboarding.repository.MerchantRepository;
import com.merchantpay.security.SecurityUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Drives merchant application intake, KYB verification, and account activation.
 */
@Service
@RequiredArgsConstructor
public class OnboardingService {

    private final MerchantApplicationRepository applicationRepository;
    private final MerchantRepository merchantRepository;
    private final KybDocumentRepository documentRepository;
    private final AuditService auditService;

    // ---------------- Applications ----------------

    @Transactional
    public ApplicationResponse createApplication(CreateApplicationRequest req) {
        if (applicationRepository.existsByRegistrationNumber(req.registrationNumber())) {
            throw new DuplicateResourceException("Application already exists for registration: " + req.registrationNumber());
        }
        MerchantApplication app = MerchantApplication.builder()
                .businessName(req.businessName())
                .registrationNumber(req.registrationNumber())
                .mcc(req.mcc())
                .businessType(req.businessType())
                .ownerName(req.ownerName())
                .nationalIdRef(req.nationalIdRef())
                .settlementBankAccountRef(req.settlementBankAccountRef())
                .submittedByUserId(SecurityUtils.getCurrentUserId())
                .status(ApplicationStatus.SUBMITTED)
                .build();
        app = applicationRepository.save(app);
        auditService.record(SecurityUtils.getCurrentUserId(), "APPLICATION_CREATED", "MerchantApplication", app.getAppId());
        return ApplicationResponse.from(app);
    }

    @Transactional(readOnly = true)
    public Page<ApplicationResponse> listApplications(ApplicationStatus status, Pageable pageable) {
        // APPLICANT can only see their own applications
        if (SecurityUtils.isApplicant()) {
            Long userId = SecurityUtils.getCurrentUserId();
            Page<MerchantApplication> page = (status == null)
                    ? applicationRepository.findBySubmittedByUserId(userId, pageable)
                    : applicationRepository.findBySubmittedByUserIdAndStatus(userId, status, pageable);
            return page.map(ApplicationResponse::from);
        }
        Page<MerchantApplication> page = (status == null)
                ? applicationRepository.findAll(pageable)
                : applicationRepository.findByStatus(status, pageable);
        return page.map(ApplicationResponse::from);
    }

    @Transactional(readOnly = true)
    public ApplicationResponse getApplication(Long appId) {
        MerchantApplication app = findApplication(appId);
        // APPLICANT can only retrieve their own application
        if (SecurityUtils.isApplicant() &&
                !SecurityUtils.getCurrentUserId().equals(app.getSubmittedByUserId())) {
            throw new com.merchantpay.common.exception.ResourceNotFoundException("MerchantApplication", appId);
        }
        return ApplicationResponse.from(app);
    }

    @Transactional
    public ApplicationResponse startKyb(Long appId) {
        MerchantApplication app = findApplication(appId);
        if (app.getStatus() != ApplicationStatus.SUBMITTED) {
            throw new BusinessRuleException("KYB can only start from SUBMITTED state");
        }
        app.setStatus(ApplicationStatus.KYB_IN_PROGRESS);
        auditService.record(SecurityUtils.getCurrentUserId(), "KYB_STARTED", "MerchantApplication", appId);
        return ApplicationResponse.from(applicationRepository.save(app));
    }

    @Transactional
    public ApplicationResponse rejectApplication(Long appId) {
        MerchantApplication app = findApplication(appId);
        if (app.getStatus() == ApplicationStatus.ACTIVE) {
            throw new BusinessRuleException("Cannot reject an already-active application");
        }
        app.setStatus(ApplicationStatus.REJECTED);
        auditService.record(SecurityUtils.getCurrentUserId(), "APPLICATION_REJECTED", "MerchantApplication", appId);
        return ApplicationResponse.from(applicationRepository.save(app));
    }

    /**
     * Approves an application and provisions the Merchant account in one transaction.
     */
    @Transactional
    public MerchantResponse approveApplication(Long appId, ApproveApplicationRequest req) {
        MerchantApplication app = findApplication(appId);
        if (app.getStatus() == ApplicationStatus.REJECTED || app.getStatus() == ApplicationStatus.ACTIVE) {
            throw new BusinessRuleException("Application in status " + app.getStatus() + " cannot be approved");
        }
        if (merchantRepository.existsByMerchantCode(req.merchantCode())) {
            throw new DuplicateResourceException("Merchant code already in use: " + req.merchantCode());
        }
        app.setStatus(ApplicationStatus.ACTIVE);
        applicationRepository.save(app);

        Merchant merchant = Merchant.builder()
                .appId(app.getAppId())
                .merchantCode(req.merchantCode())
                .businessName(app.getBusinessName())
                .mcc(app.getMcc())
                .riskCategory(req.riskCategory())
                .settlementFrequency(req.settlementFrequency())
                .feeScheduleId(req.feeScheduleId())
                .status(MerchantStatus.ACTIVE)
                .build();
        merchant = merchantRepository.save(merchant);
        auditService.record(SecurityUtils.getCurrentUserId(), "APPLICATION_APPROVED", "Merchant", merchant.getMerchantId());
        return MerchantResponse.from(merchant);
    }

    // ---------------- Merchants ----------------

    @Transactional(readOnly = true)
    public Page<MerchantResponse> listMerchants(MerchantStatus status, Pageable pageable) {
        Page<Merchant> page = (status == null)
                ? merchantRepository.findAll(pageable)
                : merchantRepository.findByStatus(status, pageable);
        return page.map(MerchantResponse::from);
    }

    @Transactional(readOnly = true)
    public MerchantResponse getMerchant(Long merchantId) {
        return MerchantResponse.from(findMerchant(merchantId));
    }

    @Transactional
    public MerchantResponse updateMerchant(Long merchantId, UpdateMerchantRequest req) {
        Merchant m = findMerchant(merchantId);
        if (req.riskCategory() != null) m.setRiskCategory(req.riskCategory());
        if (req.settlementFrequency() != null) m.setSettlementFrequency(req.settlementFrequency());
        if (req.feeScheduleId() != null) m.setFeeScheduleId(req.feeScheduleId());
        if (req.status() != null) m.setStatus(req.status());
        m = merchantRepository.save(m);
        auditService.record(SecurityUtils.getCurrentUserId(), "MERCHANT_UPDATED", "Merchant", merchantId);
        return MerchantResponse.from(m);
    }

    // ---------------- KYB Documents ----------------

    @Transactional
    public KybDocumentResponse uploadDocument(Long merchantId, KybDocumentRequest req) {
        findMerchant(merchantId); // validate existence
        KybDocument doc = KybDocument.builder()
                .merchantId(merchantId)
                .documentType(req.documentType())
                .filePath(req.filePath())
                .verificationStatus(VerificationStatus.PENDING)
                .build();
        doc = documentRepository.save(doc);
        auditService.record(SecurityUtils.getCurrentUserId(), "KYB_DOC_UPLOADED", "KybDocument", doc.getDocId());
        return KybDocumentResponse.from(doc);
    }

    @Transactional(readOnly = true)
    public Page<KybDocumentResponse> listDocuments(Long merchantId, Pageable pageable) {
        return documentRepository.findByMerchantId(merchantId, pageable).map(KybDocumentResponse::from);
    }

    @Transactional
    public KybDocumentResponse verifyDocument(Long docId, VerifyDocumentRequest req) {
        KybDocument doc = documentRepository.findById(docId)
                .orElseThrow(() -> new ResourceNotFoundException("KybDocument", docId));
        doc.setVerificationStatus(req.verificationStatus());
        doc = documentRepository.save(doc);
        auditService.record(SecurityUtils.getCurrentUserId(), "KYB_DOC_VERIFIED", "KybDocument", docId);
        return KybDocumentResponse.from(doc);
    }

    // ---------------- helpers ----------------

    private MerchantApplication findApplication(Long appId) {
        return applicationRepository.findById(appId)
                .orElseThrow(() -> new ResourceNotFoundException("MerchantApplication", appId));
    }

    private Merchant findMerchant(Long merchantId) {
        return merchantRepository.findById(merchantId)
                .orElseThrow(() -> new ResourceNotFoundException("Merchant", merchantId));
    }
}
