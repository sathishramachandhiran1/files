package com.merchantpay.onboarding.controller;

import com.merchantpay.common.enums.Enums.ApplicationStatus;
import com.merchantpay.common.enums.Enums.MerchantStatus;
import com.merchantpay.common.web.PageResponse;
import com.merchantpay.onboarding.dto.*;
import com.merchantpay.onboarding.service.OnboardingService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * Merchant onboarding, KYB verification, and merchant lifecycle management.
 */
@RestController
@RequestMapping
@RequiredArgsConstructor
@Tag(name = "Merchant Onboarding & KYB", description = "Applications, KYB documents, and merchant accounts")
public class OnboardingController {

    private final OnboardingService onboardingService;

    // ---- Applications ----

    @PostMapping("/applications")
    @PreAuthorize("hasAnyRole('ONBOARDING_OFFICER','ADMIN','APPLICANT')")
    @Operation(summary = "Submit a new merchant application")
    public ResponseEntity<ApplicationResponse> create(@Valid @RequestBody CreateApplicationRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(onboardingService.createApplication(req));
    }

    @GetMapping("/applications")
    @PreAuthorize("hasAnyRole('ONBOARDING_OFFICER','ADMIN','APPLICANT')")
    @Operation(summary = "List merchant applications, optionally filtered by status")
    public PageResponse<ApplicationResponse> list(@RequestParam(required = false) ApplicationStatus status,
                                                  Pageable pageable) {
        return PageResponse.from(onboardingService.listApplications(status, pageable), a -> a);
    }

    @GetMapping("/applications/{appId}")
    @PreAuthorize("hasAnyRole('ONBOARDING_OFFICER','ADMIN','APPLICANT')")
    @Operation(summary = "Get a merchant application by id")
    public ApplicationResponse get(@PathVariable Long appId) {
        return onboardingService.getApplication(appId);
    }

    @PostMapping("/applications/{appId}/start-kyb")
    @PreAuthorize("hasAnyRole('ONBOARDING_OFFICER','ADMIN')")
    @Operation(summary = "Move an application into KYB verification")
    public ApplicationResponse startKyb(@PathVariable Long appId) {
        return onboardingService.startKyb(appId);
    }

    @PostMapping("/applications/{appId}/reject")
    @PreAuthorize("hasAnyRole('ONBOARDING_OFFICER','ADMIN')")
    @Operation(summary = "Reject a merchant application")
    public ApplicationResponse reject(@PathVariable Long appId) {
        return onboardingService.rejectApplication(appId);
    }

    @PostMapping("/applications/{appId}/approve")
    @PreAuthorize("hasAnyRole('ONBOARDING_OFFICER','ADMIN')")
    @Operation(summary = "Approve an application and provision the merchant account")
    public ResponseEntity<MerchantResponse> approve(@PathVariable Long appId,
                                                    @Valid @RequestBody ApproveApplicationRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(onboardingService.approveApplication(appId, req));
    }

    // ---- Merchants ----

    @GetMapping("/merchants")
    @PreAuthorize("hasAnyRole('ONBOARDING_OFFICER','ACQ_OPS','ADMIN')")
    @Operation(summary = "List merchants, optionally filtered by status")
    public PageResponse<MerchantResponse> listMerchants(@RequestParam(required = false) MerchantStatus status,
                                                        Pageable pageable) {
        return PageResponse.from(onboardingService.listMerchants(status, pageable), m -> m);
    }

    @GetMapping("/merchants/{merchantId}")
    @PreAuthorize("hasAnyRole('ONBOARDING_OFFICER','ACQ_OPS','ADMIN') or (hasRole('MERCHANT') and #merchantId == authentication.principal.merchantId)")
    @Operation(summary = "Get a merchant by id")
    public MerchantResponse getMerchant(@PathVariable Long merchantId) {
        return onboardingService.getMerchant(merchantId);
    }

    @PatchMapping("/merchants/{merchantId}")
    @PreAuthorize("hasAnyRole('ONBOARDING_OFFICER','ADMIN')")
    @Operation(summary = "Update merchant risk category, settlement frequency, fee schedule, or status")
    public MerchantResponse updateMerchant(@PathVariable Long merchantId,
                                           @Valid @RequestBody UpdateMerchantRequest req) {
        return onboardingService.updateMerchant(merchantId, req);
    }

    // ---- KYB Documents ----

    @PostMapping("/merchants/{merchantId}/kyb-documents")
    @PreAuthorize("hasAnyRole('ONBOARDING_OFFICER','ADMIN','APPLICANT')")
    @Operation(summary = "Upload a KYB document for a merchant")
    public ResponseEntity<KybDocumentResponse> uploadDocument(@PathVariable Long merchantId,
                                                              @Valid @RequestBody KybDocumentRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(onboardingService.uploadDocument(merchantId, req));
    }

    @GetMapping("/merchants/{merchantId}/kyb-documents")
    @PreAuthorize("hasAnyRole('ONBOARDING_OFFICER','ADMIN')")
    @Operation(summary = "List KYB documents for a merchant")
    public PageResponse<KybDocumentResponse> listDocuments(@PathVariable Long merchantId, Pageable pageable) {
        return PageResponse.from(onboardingService.listDocuments(merchantId, pageable), d -> d);
    }

    @PatchMapping("/kyb-documents/{docId}/verify")
    @PreAuthorize("hasAnyRole('ONBOARDING_OFFICER','ADMIN')")
    @Operation(summary = "Set a KYB document's verification status")
    public KybDocumentResponse verifyDocument(@PathVariable Long docId,
                                              @Valid @RequestBody VerifyDocumentRequest req) {
        return onboardingService.verifyDocument(docId, req);
    }
}
