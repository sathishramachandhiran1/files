package com.merchantpay.onboarding.dto;

import com.merchantpay.common.enums.Enums.MerchantStatus;
import com.merchantpay.common.enums.Enums.RiskCategory;
import com.merchantpay.common.enums.Enums.SettlementFrequency;

/**
 * Partial update of merchant configuration; null fields are left unchanged.
 */
public record UpdateMerchantRequest(
        RiskCategory riskCategory,
        SettlementFrequency settlementFrequency,
        Long feeScheduleId,
        MerchantStatus status
) {
}
