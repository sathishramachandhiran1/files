package com.merchantpay.onboarding.dto;

import com.merchantpay.common.enums.Enums.ApplicationStatus;
import com.merchantpay.onboarding.domain.MerchantApplication;
import lombok.Builder;

import java.time.LocalDate;

@Builder
public record ApplicationResponse(
        Long appId,
        String businessName,
        String registrationNumber,
        String mcc,
        String businessType,
        String ownerName,
        String nationalIdRef,
        String settlementBankAccountRef,
        LocalDate applicationDate,
        ApplicationStatus status
) {
    public static ApplicationResponse from(MerchantApplication a) {
        return ApplicationResponse.builder()
                .appId(a.getAppId())
                .businessName(a.getBusinessName())
                .registrationNumber(a.getRegistrationNumber())
                .mcc(a.getMcc())
                .businessType(a.getBusinessType())
                .ownerName(a.getOwnerName())
                .nationalIdRef(a.getNationalIdRef())
                .settlementBankAccountRef(a.getSettlementBankAccountRef())
                .applicationDate(a.getApplicationDate())
                .status(a.getStatus())
                .build();
    }
}
