package com.merchantpay.onboarding.domain;

import com.merchantpay.common.domain.BaseEntity;
import com.merchantpay.common.enums.Enums.MerchantStatus;
import com.merchantpay.common.enums.Enums.RiskCategory;
import com.merchantpay.common.enums.Enums.SettlementFrequency;
import jakarta.persistence.*;
import lombok.*;

/**
 * An activated merchant account derived from an approved application.
 */
@Entity
@Table(name = "merchant", uniqueConstraints = {
        @UniqueConstraint(name = "uk_merchant_code", columnNames = "merchant_code")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Merchant extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "merchant_id")
    private Long merchantId;

    @Column(name = "app_id")
    private Long appId;

    @Column(name = "merchant_code", nullable = false)
    private String merchantCode;

    @Column(name = "business_name", nullable = false)
    private String businessName;

    @Column(length = 8)
    private String mcc;

    @Enumerated(EnumType.STRING)
    @Column(name = "risk_category", length = 8)
    @Builder.Default
    private RiskCategory riskCategory = RiskCategory.LOW;

    @Enumerated(EnumType.STRING)
    @Column(name = "settlement_frequency", length = 8)
    @Builder.Default
    private SettlementFrequency settlementFrequency = SettlementFrequency.DAILY;

    @Column(name = "fee_schedule_id")
    private Long feeScheduleId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 16)
    @Builder.Default
    private MerchantStatus status = MerchantStatus.ACTIVE;
}
