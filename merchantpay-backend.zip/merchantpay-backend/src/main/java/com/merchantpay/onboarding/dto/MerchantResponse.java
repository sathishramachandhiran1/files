package com.merchantpay.onboarding.dto;

import com.merchantpay.common.enums.Enums.MerchantStatus;
import com.merchantpay.common.enums.Enums.RiskCategory;
import com.merchantpay.common.enums.Enums.SettlementFrequency;
import com.merchantpay.onboarding.domain.Merchant;
import lombok.Builder;

@Builder
public record MerchantResponse(
        Long merchantId,
        Long appId,
        String merchantCode,
        String businessName,
        String mcc,
        RiskCategory riskCategory,
        SettlementFrequency settlementFrequency,
        Long feeScheduleId,
        MerchantStatus status
) {
    public static MerchantResponse from(Merchant m) {
        return MerchantResponse.builder()
                .merchantId(m.getMerchantId())
                .appId(m.getAppId())
                .merchantCode(m.getMerchantCode())
                .businessName(m.getBusinessName())
                .mcc(m.getMcc())
                .riskCategory(m.getRiskCategory())
                .settlementFrequency(m.getSettlementFrequency())
                .feeScheduleId(m.getFeeScheduleId())
                .status(m.getStatus())
                .build();
    }
}
