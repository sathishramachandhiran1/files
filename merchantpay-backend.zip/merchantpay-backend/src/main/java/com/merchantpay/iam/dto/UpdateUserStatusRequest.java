package com.merchantpay.iam.dto;

import com.merchantpay.common.enums.Enums.UserStatus;
import jakarta.validation.constraints.NotNull;

public record UpdateUserStatusRequest(@NotNull UserStatus status) {
}
