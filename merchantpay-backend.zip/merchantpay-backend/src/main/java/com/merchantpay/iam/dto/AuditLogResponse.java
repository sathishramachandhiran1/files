package com.merchantpay.iam.dto;

import com.merchantpay.iam.domain.AuditLog;

import java.time.Instant;

public record AuditLogResponse(
        Long auditId,
        Long userId,
        String action,
        String entityType,
        String recordId,
        Instant timestamp
) {
    public static AuditLogResponse from(AuditLog a) {
        return new AuditLogResponse(a.getAuditId(), a.getUserId(), a.getAction(),
                a.getEntityType(), a.getRecordId(), a.getTimestamp());
    }
}
