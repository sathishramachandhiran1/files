package com.merchantpay.iam.dto;

import com.merchantpay.common.enums.Enums.UserStatus;
import com.merchantpay.common.enums.Role;
import com.merchantpay.iam.domain.User;
import lombok.Builder;

@Builder
public record UserResponse(
        Long userId,
        String name,
        Role role,
        String email,
        String phone,
        Long merchantId,
        UserStatus status
) {
    public static UserResponse from(User u) {
        return UserResponse.builder()
                .userId(u.getUserId())
                .name(u.getName())
                .role(u.getRole())
                .email(u.getEmail())
                .phone(u.getPhone())
                .merchantId(u.getMerchantId())
                .status(u.getStatus())
                .build();
    }
}
