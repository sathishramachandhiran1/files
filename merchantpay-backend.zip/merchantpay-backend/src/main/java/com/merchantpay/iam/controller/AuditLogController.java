package com.merchantpay.iam.controller;

import com.merchantpay.common.web.PageResponse;
import com.merchantpay.iam.dto.AuditLogResponse;
import com.merchantpay.iam.repository.AuditLogRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * Read-only access to the audit trail. Admin only.
 */
@RestController
@RequestMapping("/audit-logs")
@RequiredArgsConstructor
@Tag(name = "Audit Logs", description = "Compliance audit trail (admin only)")
@PreAuthorize("hasRole('ADMIN')")
public class AuditLogController {

    private final AuditLogRepository auditLogRepository;

    @GetMapping
    @Operation(summary = "List audit log entries, optionally filtered by entity")
    public PageResponse<AuditLogResponse> list(
            @RequestParam(required = false) String entityType,
            @RequestParam(required = false) String recordId,
            Pageable pageable) {
        if (entityType != null && recordId != null) {
            return PageResponse.from(
                    auditLogRepository.findByEntityTypeAndRecordId(entityType, recordId, pageable),
                    AuditLogResponse::from);
        }
        return PageResponse.from(auditLogRepository.findAll(pageable), AuditLogResponse::from);
    }
}
