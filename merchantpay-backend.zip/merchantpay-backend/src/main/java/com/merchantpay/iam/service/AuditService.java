package com.merchantpay.iam.service;

import com.merchantpay.iam.domain.AuditLog;
import com.merchantpay.iam.repository.AuditLogRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * Writes audit trail entries for security- and compliance-relevant actions
 * (transaction overrides, chargeback decisions, fee adjustments, etc.).
 */
@Service
@RequiredArgsConstructor
public class AuditService {

    private final AuditLogRepository auditLogRepository;

    /**
     * Records an audit entry in its own transaction so audit logging never
     * rolls back business work and is never rolled back by it.
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void record(Long userId, String action, String entityType, Object recordId) {
        AuditLog log = AuditLog.builder()
                .userId(userId)
                .action(action)
                .entityType(entityType)
                .recordId(recordId == null ? null : String.valueOf(recordId))
                .build();
        auditLogRepository.save(log);
    }
}
