package com.merchantpay.iam.service;

import com.merchantpay.common.exception.ResourceNotFoundException;
import com.merchantpay.iam.domain.User;
import com.merchantpay.iam.dto.UpdateUserStatusRequest;
import com.merchantpay.iam.dto.UserResponse;
import com.merchantpay.iam.repository.UserRepository;
import com.merchantpay.security.SecurityUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final AuditService auditService;

    @Transactional(readOnly = true)
    public Page<User> list(Pageable pageable) {
        return userRepository.findAll(pageable);
    }

    @Transactional(readOnly = true)
    public User getById(Long userId) {
        return userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", userId));
    }

    @Transactional(readOnly = true)
    public UserResponse getCurrent() {
        Long id = SecurityUtils.getCurrentUserId();
        return UserResponse.from(getById(id));
    }

    @Transactional
    public UserResponse updateStatus(Long userId, UpdateUserStatusRequest request) {
        User user = getById(userId);
        user.setStatus(request.status());
        user = userRepository.save(user);
        auditService.record(SecurityUtils.getCurrentUserId(), "USER_STATUS_CHANGED", "User", userId);
        return UserResponse.from(user);
    }
}
