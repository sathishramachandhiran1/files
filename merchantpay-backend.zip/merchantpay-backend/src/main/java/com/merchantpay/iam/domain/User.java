package com.merchantpay.iam.domain;

import com.merchantpay.common.domain.BaseEntity;
import com.merchantpay.common.enums.Enums.UserStatus;
import com.merchantpay.common.enums.Role;
import jakarta.persistence.*;
import lombok.*;

/**
 * Platform user. May be a merchant user (scoped via merchantId) or acquirer staff.
 */
@Entity
@Table(name = "users", uniqueConstraints = {
        @UniqueConstraint(name = "uk_users_email", columnNames = "email")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    private Long userId;

    @Column(nullable = false)
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 32)
    private Role role;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(length = 32)
    private String phone;

    @Column(name = "password_hash", nullable = false)
    private String passwordHash;

    /** Merchant scope for MERCHANT-role users; null for acquirer staff. */
    @Column(name = "merchant_id")
    private Long merchantId;
    

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 16)
    @Builder.Default
    private UserStatus status = UserStatus.ACTIVE;
}
