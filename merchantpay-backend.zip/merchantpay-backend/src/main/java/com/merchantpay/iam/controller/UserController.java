package com.merchantpay.iam.controller;

import com.merchantpay.common.web.PageResponse;
import com.merchantpay.iam.dto.UpdateUserStatusRequest;
import com.merchantpay.iam.dto.UserResponse;
import com.merchantpay.iam.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * User administration. Restricted to administrators except /me.
 */
@RestController
@RequestMapping("/users")
@RequiredArgsConstructor
@Tag(name = "Users", description = "User administration and profile")
public class UserController {

    private final UserService userService;

    @GetMapping("/me")
    @Operation(summary = "Get the currently authenticated user's profile")
    public UserResponse me() {
        return userService.getCurrent();
    }

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "List all users (admin only)")
    public PageResponse<UserResponse> list(Pageable pageable) {
        return PageResponse.from(userService.list(pageable), UserResponse::from);
    }

    @GetMapping("/{userId}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Get a user by id (admin only)")
    public UserResponse get(@PathVariable Long userId) {
        return UserResponse.from(userService.getById(userId));
    }

    @PatchMapping("/{userId}/status")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Activate, lock, or deactivate a user (admin only)")
    public UserResponse updateStatus(@PathVariable Long userId,
                                     @Valid @RequestBody UpdateUserStatusRequest request) {
        return userService.updateStatus(userId, request);
    }
}
