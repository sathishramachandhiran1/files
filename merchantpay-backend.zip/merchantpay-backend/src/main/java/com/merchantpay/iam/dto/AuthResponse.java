package com.merchantpay.iam.dto;

import lombok.Builder;

@Builder
public record AuthResponse(
        String accessToken,
        String tokenType,
        UserResponse user
) {
}