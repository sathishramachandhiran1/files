package com.merchantpay.terminal.domain;

import com.merchantpay.common.domain.BaseEntity;
import com.merchantpay.common.enums.Enums.TerminalStatus;
import com.merchantpay.common.enums.Enums.TerminalType;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

/**
 * A physical or virtual payment terminal provisioned to a merchant.
 */
@Entity
@Table(name = "terminal", uniqueConstraints = {
        @UniqueConstraint(name = "uk_terminal_serial", columnNames = "serial_number")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Terminal extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "terminal_id")
    private Long terminalId;

    @Column(name = "merchant_id", nullable = false)
    private Long merchantId;

    @Enumerated(EnumType.STRING)
    @Column(name = "terminal_type", nullable = false, length = 16)
    private TerminalType terminalType;

    @Column(name = "serial_number")
    private String serialNumber;

    @Column(name = "model")
    private String model;

    @Column(name = "provisioned_date")
    private LocalDate provisionedDate;

    @Column(name = "location_description")
    private String locationDescription;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    @Builder.Default
    private TerminalStatus status = TerminalStatus.ACTIVE;

    @PrePersist
    void defaultDates() {
        if (provisionedDate == null) {
            provisionedDate = LocalDate.now();
        }
    }
}
