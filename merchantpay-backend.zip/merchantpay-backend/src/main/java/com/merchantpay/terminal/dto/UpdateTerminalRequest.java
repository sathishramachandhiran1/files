package com.merchantpay.terminal.dto;

import com.merchantpay.common.enums.Enums.TerminalStatus;
import jakarta.validation.constraints.Size;

/**
 * Request payload for a partial update of a terminal. Null fields are left unchanged.
 */
public record UpdateTerminalRequest(

        TerminalStatus status,

        @Size(max = 255, message = "locationDescription must be at most 255 characters")
        String locationDescription,

        @Size(max = 100, message = "model must be at most 100 characters")
        String model
) {
}
