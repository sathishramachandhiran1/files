package com.merchantpay.terminal.dto;

import com.merchantpay.common.enums.Enums.TerminalType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/**
 * Request payload for provisioning a new terminal.
 */
public record CreateTerminalRequest(

        @NotNull(message = "merchantId is required")
        Long merchantId,

        @NotNull(message = "terminalType is required")
        TerminalType terminalType,

        @Size(max = 100, message = "serialNumber must be at most 100 characters")
        String serialNumber,

        @Size(max = 100, message = "model must be at most 100 characters")
        String model,

        @Size(max = 255, message = "locationDescription must be at most 255 characters")
        String locationDescription
) {
}
