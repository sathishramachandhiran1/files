package com.merchantpay.terminal.controller;

import com.merchantpay.common.enums.Enums.TerminalStatus;
import com.merchantpay.common.web.PageResponse;
import com.merchantpay.terminal.dto.*;
import com.merchantpay.terminal.service.TerminalService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * Terminal provisioning, lifecycle management, and event recording.
 */
@RestController
@RequestMapping("/terminals")
@RequiredArgsConstructor
@Tag(name = "Terminal & Device Management", description = "Provision and manage payment terminals and their lifecycle events")
public class TerminalController {

    private final TerminalService terminalService;

    @PostMapping
    @PreAuthorize("hasAnyRole('ACQ_OPS','ADMIN')")
    @Operation(summary = "Provision a new terminal for a merchant")
    public ResponseEntity<TerminalResponse> provision(@Valid @RequestBody CreateTerminalRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(terminalService.provisionTerminal(req));
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ACQ_OPS','ADMIN','ONBOARDING_OFFICER') or (hasRole('MERCHANT') and #merchantId == authentication.principal.merchantId)")
    @Operation(summary = "List terminals, optionally filtered by merchantId and/or status")
    public PageResponse<TerminalResponse> list(@RequestParam(required = false) Long merchantId,
                                               @RequestParam(required = false) TerminalStatus status,
                                               Pageable pageable) {
        return PageResponse.from(terminalService.listTerminals(merchantId, status, pageable), t -> t);
    }

    @GetMapping("/{terminalId}")
    @PreAuthorize("hasAnyRole('ACQ_OPS','ADMIN','ONBOARDING_OFFICER') or (hasRole('MERCHANT') and #merchantId == authentication.principal.merchantId)")
    @Operation(summary = "Get a terminal by id")
    public TerminalResponse get(@PathVariable Long terminalId) {
        return terminalService.getTerminal(terminalId);
    }

    @PatchMapping("/{terminalId}")
    @PreAuthorize("hasAnyRole('ACQ_OPS','ADMIN')")
    @Operation(summary = "Update a terminal's status, location description, or model")
    public TerminalResponse update(@PathVariable Long terminalId,
                                   @Valid @RequestBody UpdateTerminalRequest req) {
        return terminalService.updateTerminal(terminalId, req);
    }

    @PostMapping("/{terminalId}/decommission")
    @PreAuthorize("hasAnyRole('ACQ_OPS','ADMIN')")
    @Operation(summary = "Decommission a terminal and auto-record a DECOMMISSION event")
    public TerminalResponse decommission(@PathVariable Long terminalId) {
        return terminalService.decommissionTerminal(terminalId);
    }

    @PostMapping("/{terminalId}/events")
    @PreAuthorize("hasAnyRole('ACQ_OPS','ADMIN')")
    @Operation(summary = "Record a lifecycle event for a terminal")
    public ResponseEntity<TerminalEventResponse> recordEvent(@PathVariable Long terminalId,
                                                             @Valid @RequestBody CreateTerminalEventRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(terminalService.recordEvent(terminalId, req));
    }

    @GetMapping("/{terminalId}/events")
    @PreAuthorize("hasAnyRole('ACQ_OPS','ADMIN','ONBOARDING_OFFICER') or (hasRole('MERCHANT') and #merchantId == authentication.principal.merchantId)")
    @Operation(summary = "List events for a terminal")
    public PageResponse<TerminalEventResponse> listEvents(@PathVariable Long terminalId, Pageable pageable) {
        return PageResponse.from(terminalService.listEvents(terminalId, pageable), e -> e);
    }
}
