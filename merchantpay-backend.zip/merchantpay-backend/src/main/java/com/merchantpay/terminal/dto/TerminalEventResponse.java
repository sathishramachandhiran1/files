package com.merchantpay.terminal.dto;

import com.merchantpay.common.enums.Enums.TerminalEventStatus;
import com.merchantpay.common.enums.Enums.TerminalEventType;
import com.merchantpay.terminal.domain.TerminalEvent;
import lombok.Builder;

import java.time.LocalDate;

/**
 * Read-only projection of a {@link TerminalEvent} entity.
 */
@Builder
public record TerminalEventResponse(
        Long eventId,
        Long terminalId,
        TerminalEventType eventType,
        LocalDate eventDate,
        Long performedById,
        String notes,
        TerminalEventStatus status
) {
    public static TerminalEventResponse from(TerminalEvent e) {
        return TerminalEventResponse.builder()
                .eventId(e.getEventId())
                .terminalId(e.getTerminalId())
                .eventType(e.getEventType())
                .eventDate(e.getEventDate())
                .performedById(e.getPerformedById())
                .notes(e.getNotes())
                .status(e.getStatus())
                .build();
    }
}
