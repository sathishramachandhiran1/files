package com.merchantpay.terminal.dto;

import com.merchantpay.common.enums.Enums.TerminalEventStatus;
import com.merchantpay.common.enums.Enums.TerminalEventType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/**
 * Request payload for recording a terminal lifecycle event.
 */
public record CreateTerminalEventRequest(

        @NotNull(message = "eventType is required")
        TerminalEventType eventType,

        Long performedById,

        @Size(max = 1000, message = "notes must be at most 1000 characters")
        String notes,

        TerminalEventStatus status
) {
}
