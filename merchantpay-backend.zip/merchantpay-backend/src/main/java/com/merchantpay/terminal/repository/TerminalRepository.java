package com.merchantpay.terminal.repository;

import com.merchantpay.common.enums.Enums.TerminalStatus;
import com.merchantpay.terminal.domain.Terminal;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Spring Data repository for {@link Terminal} entities.
 */
public interface TerminalRepository extends JpaRepository<Terminal, Long> {

    boolean existsBySerialNumber(String serialNumber);

    Page<Terminal> findByMerchantId(Long merchantId, Pageable pageable);

    Page<Terminal> findByStatus(TerminalStatus status, Pageable pageable);

    Page<Terminal> findByMerchantIdAndStatus(Long merchantId, TerminalStatus status, Pageable pageable);
}
