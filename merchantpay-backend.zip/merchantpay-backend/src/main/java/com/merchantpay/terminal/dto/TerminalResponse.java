package com.merchantpay.terminal.dto;

import com.merchantpay.common.enums.Enums.TerminalStatus;
import com.merchantpay.common.enums.Enums.TerminalType;
import com.merchantpay.terminal.domain.Terminal;
import lombok.Builder;

import java.time.LocalDate;

/**
 * Read-only projection of a {@link Terminal} entity.
 */
@Builder
public record TerminalResponse(
        Long terminalId,
        Long merchantId,
        TerminalType terminalType,
        String serialNumber,
        String model,
        LocalDate provisionedDate,
        String locationDescription,
        TerminalStatus status
) {
    public static TerminalResponse from(Terminal t) {
        return TerminalResponse.builder()
                .terminalId(t.getTerminalId())
                .merchantId(t.getMerchantId())
                .terminalType(t.getTerminalType())
                .serialNumber(t.getSerialNumber())
                .model(t.getModel())
                .provisionedDate(t.getProvisionedDate())
                .locationDescription(t.getLocationDescription())
                .status(t.getStatus())
                .build();
    }
}
