package com.merchantpay.terminal.service;

import com.merchantpay.common.enums.Enums.TerminalEventStatus;
import com.merchantpay.common.enums.Enums.TerminalEventType;
import com.merchantpay.common.enums.Enums.TerminalStatus;
import com.merchantpay.common.exception.BusinessRuleException;
import com.merchantpay.common.exception.DuplicateResourceException;
import com.merchantpay.common.exception.ResourceNotFoundException;
import com.merchantpay.iam.service.AuditService;
import com.merchantpay.security.SecurityUtils;
import com.merchantpay.terminal.domain.Terminal;
import com.merchantpay.terminal.domain.TerminalEvent;
import com.merchantpay.terminal.dto.*;
import com.merchantpay.terminal.repository.TerminalEventRepository;
import com.merchantpay.terminal.repository.TerminalRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Business logic for terminal provisioning, lifecycle management, and event recording.
 */
@Service
@RequiredArgsConstructor
public class TerminalService {

    private final TerminalRepository terminalRepository;
    private final TerminalEventRepository terminalEventRepository;
    private final AuditService auditService;

    // ---------------- Terminals ----------------

    @Transactional
    public TerminalResponse provisionTerminal(CreateTerminalRequest req) {
        if (req.serialNumber() != null && terminalRepository.existsBySerialNumber(req.serialNumber())) {
            throw new DuplicateResourceException("Terminal already exists with serial number: " + req.serialNumber());
        }
        Terminal terminal = Terminal.builder()
                .merchantId(req.merchantId())
                .terminalType(req.terminalType())
                .serialNumber(req.serialNumber())
                .model(req.model())
                .locationDescription(req.locationDescription())
                .status(TerminalStatus.ACTIVE)
                .build();
        terminal = terminalRepository.save(terminal);
        auditService.record(SecurityUtils.getCurrentUserId(), "TERMINAL_PROVISIONED", "Terminal", terminal.getTerminalId());
        return TerminalResponse.from(terminal);
    }

    @Transactional(readOnly = true)
    public Page<TerminalResponse> listTerminals(Long merchantId, TerminalStatus status, Pageable pageable) {
        Page<Terminal> page;
        if (merchantId != null && status != null) {
            page = terminalRepository.findByMerchantIdAndStatus(merchantId, status, pageable);
        } else if (merchantId != null) {
            page = terminalRepository.findByMerchantId(merchantId, pageable);
        } else if (status != null) {
            page = terminalRepository.findByStatus(status, pageable);
        } else {
            page = terminalRepository.findAll(pageable);
        }
        return page.map(TerminalResponse::from);
    }

    @Transactional(readOnly = true)
    public TerminalResponse getTerminal(Long terminalId) {
        return TerminalResponse.from(findTerminal(terminalId));
    }

    @Transactional
    public TerminalResponse updateTerminal(Long terminalId, UpdateTerminalRequest req) {
        Terminal terminal = findTerminal(terminalId);
        if (req.status() != null) terminal.setStatus(req.status());
        if (req.locationDescription() != null) terminal.setLocationDescription(req.locationDescription());
        if (req.model() != null) terminal.setModel(req.model());
        terminal = terminalRepository.save(terminal);
        auditService.record(SecurityUtils.getCurrentUserId(), "TERMINAL_UPDATED", "Terminal", terminalId);
        return TerminalResponse.from(terminal);
    }

    @Transactional
    public TerminalResponse decommissionTerminal(Long terminalId) {
        Terminal terminal = findTerminal(terminalId);
        if (terminal.getStatus() == TerminalStatus.DECOMMISSIONED) {
            throw new BusinessRuleException("Terminal " + terminalId + " is already DECOMMISSIONED");
        }
        terminal.setStatus(TerminalStatus.DECOMMISSIONED);
        terminal = terminalRepository.save(terminal);

        TerminalEvent event = TerminalEvent.builder()
                .terminalId(terminalId)
                .eventType(TerminalEventType.DECOMMISSION)
                .status(TerminalEventStatus.COMPLETED)
                .build();
        terminalEventRepository.save(event);

        auditService.record(SecurityUtils.getCurrentUserId(), "TERMINAL_DECOMMISSIONED", "Terminal", terminalId);
        return TerminalResponse.from(terminal);
    }

    // ---------------- Terminal Events ----------------

    @Transactional
    public TerminalEventResponse recordEvent(Long terminalId, CreateTerminalEventRequest req) {
        findTerminal(terminalId); // validate existence
        TerminalEvent event = TerminalEvent.builder()
                .terminalId(terminalId)
                .eventType(req.eventType())
                .performedById(req.performedById())
                .notes(req.notes())
                .status(req.status() != null ? req.status() : TerminalEventStatus.COMPLETED)
                .build();
        event = terminalEventRepository.save(event);
        auditService.record(SecurityUtils.getCurrentUserId(), "TERMINAL_EVENT_RECORDED", "TerminalEvent", event.getEventId());
        return TerminalEventResponse.from(event);
    }

    @Transactional(readOnly = true)
    public Page<TerminalEventResponse> listEvents(Long terminalId, Pageable pageable) {
        findTerminal(terminalId); // validate existence
        return terminalEventRepository.findByTerminalId(terminalId, pageable).map(TerminalEventResponse::from);
    }

    // ---------------- helpers ----------------

    private Terminal findTerminal(Long terminalId) {
        return terminalRepository.findById(terminalId)
                .orElseThrow(() -> new ResourceNotFoundException("Terminal", terminalId));
    }
}
