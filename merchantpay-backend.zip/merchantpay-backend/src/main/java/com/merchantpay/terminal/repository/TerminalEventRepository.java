package com.merchantpay.terminal.repository;

import com.merchantpay.terminal.domain.TerminalEvent;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Spring Data repository for {@link TerminalEvent} entities.
 */
public interface TerminalEventRepository extends JpaRepository<TerminalEvent, Long> {

    Page<TerminalEvent> findByTerminalId(Long terminalId, Pageable pageable);
}
