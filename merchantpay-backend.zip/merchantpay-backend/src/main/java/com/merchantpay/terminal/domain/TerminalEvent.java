package com.merchantpay.terminal.domain;

import com.merchantpay.common.domain.BaseEntity;
import com.merchantpay.common.enums.Enums.TerminalEventStatus;
import com.merchantpay.common.enums.Enums.TerminalEventType;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

/**
 * An audit event recording an operation performed on a terminal (e.g. deployment, swap, repair).
 */
@Entity
@Table(name = "terminal_event", indexes = {
        @Index(name = "idx_terminal_event_terminal_id", columnList = "terminal_id")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TerminalEvent extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "event_id")
    private Long eventId;

    @Column(name = "terminal_id", nullable = false)
    private Long terminalId;

    @Enumerated(EnumType.STRING)
    @Column(name = "event_type", nullable = false, length = 20)
    private TerminalEventType eventType;

    @Column(name = "event_date")
    private LocalDate eventDate;

    @Column(name = "performed_by_id")
    private Long performedById;

    @Column(name = "notes", length = 1000)
    private String notes;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 16)
    @Builder.Default
    private TerminalEventStatus status = TerminalEventStatus.COMPLETED;

    @PrePersist
    void defaultDates() {
        if (eventDate == null) {
            eventDate = LocalDate.now();
        }
    }
}
