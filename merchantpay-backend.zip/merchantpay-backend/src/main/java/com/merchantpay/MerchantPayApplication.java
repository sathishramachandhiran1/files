package com.merchantpay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

/**
 * MerchantPay - Payment Gateway & Merchant Acquiring Platform.
 * Application entry point.
 */
@SpringBootApplication
@EnableJpaAuditing
public class MerchantPayApplication {

    public static void main(String[] args) {
        SpringApplication.run(MerchantPayApplication.class, args);
    }
}
