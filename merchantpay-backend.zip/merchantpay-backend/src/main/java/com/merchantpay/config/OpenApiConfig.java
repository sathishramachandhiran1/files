package com.merchantpay.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Springdoc/OpenAPI 3 configuration. Exposes Bearer-JWT auth in Swagger UI.
 */
@Configuration
public class OpenApiConfig {

    private static final String SECURITY_SCHEME = "bearer-jwt";

    @Bean
    public OpenAPI merchantPayOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("MerchantPay API")
                        .description("Payment Gateway & Merchant Acquiring Platform - REST API. "
                                + "Covers IAM, merchant onboarding/KYB, terminal management, transaction "
                                + "processing, settlement, chargeback/dispute, fraud monitoring, and notifications.")
                        .version("1.0.0")
                        .contact(new Contact().name("MerchantPay Engineering").email("api@merchantpay.example"))
                        .license(new License().name("Proprietary")))
                .addSecurityItem(new SecurityRequirement().addList(SECURITY_SCHEME))
                .components(new Components().addSecuritySchemes(SECURITY_SCHEME,
                        new SecurityScheme()
                                .name(SECURITY_SCHEME)
                                .type(SecurityScheme.Type.HTTP)
                                .scheme("bearer")
                                .bearerFormat("JWT")
                                .description("Paste the access token obtained from POST /auth/login")));
    }
}
