package com.merchantpay.config;

import com.merchantpay.common.enums.Enums.UserStatus;
import com.merchantpay.common.enums.Role;
import com.merchantpay.iam.domain.User;
import com.merchantpay.iam.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * Seeds a default admin account for local development so Swagger UI can authenticate.
 * Active only under the "local" profile.
 */
@Slf4j
@Component
@Profile("local")
@RequiredArgsConstructor
public class LocalDataSeeder implements CommandLineRunner {

    private static final String ADMIN_EMAIL = "admin@merchantpay.local";
    private static final String ADMIN_PASSWORD = "Admin@12345";

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        if (userRepository.existsByEmail(ADMIN_EMAIL)) {
            return;
        }
        User admin = User.builder()
                .name("Platform Administrator")
                .role(Role.ADMIN)
                .email(ADMIN_EMAIL)
                .phone("+10000000000")
                .passwordHash(passwordEncoder.encode(ADMIN_PASSWORD))
                .status(UserStatus.ACTIVE)
                .build();
        userRepository.save(admin);
        log.info("Seeded default admin -> email: {} / password: {}", ADMIN_EMAIL, ADMIN_PASSWORD);
    }
}
