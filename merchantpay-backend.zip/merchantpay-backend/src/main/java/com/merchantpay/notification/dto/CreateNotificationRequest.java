package com.merchantpay.notification.dto;

import com.merchantpay.common.enums.Enums.NotificationCategory;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/**
 * Request body for creating a notification on behalf of a target user.
 */
public record CreateNotificationRequest(

        @NotNull(message = "userId is required")
        Long userId,

        @NotBlank(message = "message is required")
        @Size(max = 1000, message = "message must not exceed 1000 characters")
        String message,

        @NotNull(message = "category is required")
        NotificationCategory category
) {
}
