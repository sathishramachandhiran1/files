package com.merchantpay.notification.controller;

import com.merchantpay.common.enums.Enums.NotificationStatus;
import com.merchantpay.common.web.PageResponse;
import com.merchantpay.notification.dto.CreateNotificationRequest;
import com.merchantpay.notification.dto.NotificationResponse;
import com.merchantpay.notification.dto.UnreadCountResponse;
import com.merchantpay.notification.service.NotificationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * REST endpoints for user notifications: creation (admin), listing, unread counts,
 * mark-read, and dismiss.
 */
@RestController
@RequestMapping("/notifications")
@RequiredArgsConstructor
@Tag(name = "Notifications & Alerts", description = "User notification management and delivery status")
public class NotificationController {

    private final NotificationService notificationService;

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','ACQ_OPS','DISPUTE_ANALYST','FRAUD_ANALYST')")
    @Operation(summary = "Create a notification for a target user")
    public ResponseEntity<NotificationResponse> create(@Valid @RequestBody CreateNotificationRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(notificationService.create(req));
    }

    @GetMapping
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "List the current user's notifications, optionally filtered by status")
    public PageResponse<NotificationResponse> list(@RequestParam(required = false) NotificationStatus status,
                                                   Pageable pageable) {
        return PageResponse.from(notificationService.listForCurrentUser(status, pageable), n -> n);
    }

    @GetMapping("/unread-count")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Get the unread notification count for the current user")
    public UnreadCountResponse unreadCount() {
        return notificationService.unreadCountForCurrentUser();
    }

    @PostMapping("/{notificationId}/read")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Mark a notification as read")
    public NotificationResponse markRead(@PathVariable Long notificationId) {
        return notificationService.markRead(notificationId);
    }

    @PostMapping("/{notificationId}/dismiss")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Dismiss a notification")
    public NotificationResponse dismiss(@PathVariable Long notificationId) {
        return notificationService.dismiss(notificationId);
    }
}
