package com.merchantpay.notification.service;

import com.merchantpay.common.enums.Enums.NotificationCategory;
import com.merchantpay.common.enums.Enums.NotificationStatus;
import com.merchantpay.common.exception.ResourceNotFoundException;
import com.merchantpay.iam.service.AuditService;
import com.merchantpay.notification.domain.Notification;
import com.merchantpay.notification.dto.CreateNotificationRequest;
import com.merchantpay.notification.dto.NotificationResponse;
import com.merchantpay.notification.dto.UnreadCountResponse;
import com.merchantpay.notification.repository.NotificationRepository;
import com.merchantpay.security.SecurityUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Business logic for creating, querying, and mutating user notifications.
 */
@Service
@RequiredArgsConstructor
@Transactional
public class NotificationService {

    private final NotificationRepository notificationRepository;
    private final AuditService auditService;

    // ---------------- Write (admin/internal) ----------------

    /**
     * Creates a notification for the target user specified in the request.
     * Intended for privileged callers; no security-context scoping on the target.
     */
    public NotificationResponse create(CreateNotificationRequest req) {
        Notification saved = notify(req.userId(), req.message(), req.category());
        auditService.record(SecurityUtils.getCurrentUserId(), "NOTIFICATION_CREATED", "Notification", saved.getNotificationId());
        return NotificationResponse.from(saved);
    }

    /**
     * Programmatic entry-point for other modules to raise a notification without
     * depending on a security context. Returns the persisted entity.
     */
    public Notification notify(Long userId, String message, NotificationCategory category) {
        Notification notification = Notification.builder()
                .userId(userId)
                .message(message)
                .category(category)
                .build();
        return notificationRepository.save(notification);
    }

    // ---------------- Read (current user) ----------------

    @Transactional(readOnly = true)
    public Page<NotificationResponse> listForCurrentUser(NotificationStatus status, Pageable pageable) {
        Long userId = SecurityUtils.getCurrentUserId();
        Page<Notification> page = (status == null)
                ? notificationRepository.findByUserId(userId, pageable)
                : notificationRepository.findByUserIdAndStatus(userId, status, pageable);
        return page.map(NotificationResponse::from);
    }

    @Transactional(readOnly = true)
    public UnreadCountResponse unreadCountForCurrentUser() {
        Long userId = SecurityUtils.getCurrentUserId();
        long count = notificationRepository.countByUserIdAndStatus(userId, NotificationStatus.UNREAD);
        return new UnreadCountResponse(count);
    }

    // ---------------- Mutations (current user) ----------------

    public NotificationResponse markRead(Long notificationId) {
        Notification notification = findOwnedNotification(notificationId);
        notification.setStatus(NotificationStatus.READ);
        Notification saved = notificationRepository.save(notification);
        auditService.record(SecurityUtils.getCurrentUserId(), "NOTIFICATION_READ", "Notification", notificationId);
        return NotificationResponse.from(saved);
    }

    public NotificationResponse dismiss(Long notificationId) {
        Notification notification = findOwnedNotification(notificationId);
        notification.setStatus(NotificationStatus.DISMISSED);
        Notification saved = notificationRepository.save(notification);
        auditService.record(SecurityUtils.getCurrentUserId(), "NOTIFICATION_DISMISSED", "Notification", notificationId);
        return NotificationResponse.from(saved);
    }

    // ---------------- helpers ----------------

    /**
     * Loads a notification by id and verifies it belongs to the current user.
     * Throws {@link ResourceNotFoundException} either when it does not exist or
     * belongs to a different user (no existence leakage).
     */
    private Notification findOwnedNotification(Long notificationId) {
        Long userId = SecurityUtils.getCurrentUserId();
        Notification notification = notificationRepository.findById(notificationId)
                .orElseThrow(() -> new ResourceNotFoundException("Notification", notificationId));
        if (!notification.getUserId().equals(userId)) {
            throw new ResourceNotFoundException("Notification", notificationId);
        }
        return notification;
    }
}
