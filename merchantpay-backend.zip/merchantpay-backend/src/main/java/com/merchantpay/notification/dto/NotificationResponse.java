package com.merchantpay.notification.dto;

import com.merchantpay.common.enums.Enums.NotificationCategory;
import com.merchantpay.common.enums.Enums.NotificationStatus;
import com.merchantpay.notification.domain.Notification;

import java.time.Instant;

/**
 * Read-side projection of a {@link Notification} returned to API consumers.
 */
public record NotificationResponse(
        Long notificationId,
        Long userId,
        String message,
        NotificationCategory category,
        NotificationStatus status,
        Instant createdDate
) {
    public static NotificationResponse from(Notification n) {
        return new NotificationResponse(
                n.getNotificationId(),
                n.getUserId(),
                n.getMessage(),
                n.getCategory(),
                n.getStatus(),
                n.getCreatedDate()
        );
    }
}
