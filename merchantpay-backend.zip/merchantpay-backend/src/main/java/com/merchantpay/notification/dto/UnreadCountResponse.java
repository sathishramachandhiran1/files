package com.merchantpay.notification.dto;

/**
 * Carries the unread notification count for the current user.
 */
public record UnreadCountResponse(long unreadCount) {
}
