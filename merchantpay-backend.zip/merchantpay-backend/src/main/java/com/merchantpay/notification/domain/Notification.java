package com.merchantpay.notification.domain;

import com.merchantpay.common.domain.BaseEntity;
import com.merchantpay.common.enums.Enums.NotificationCategory;
import com.merchantpay.common.enums.Enums.NotificationStatus;
import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

/**
 * A platform notification delivered to a specific user, categorised by business domain.
 */
@Entity
@Table(name = "notification", indexes = @Index(name = "idx_notification_user", columnList = "user_id"))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Notification extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "notification_id")
    private Long notificationId;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "message", nullable = false, length = 1000)
    private String message;

    @Enumerated(EnumType.STRING)
    @Column(name = "category", nullable = false, length = 32)
    private NotificationCategory category;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 16)
    @Builder.Default
    private NotificationStatus status = NotificationStatus.UNREAD;

    @Column(name = "created_date", nullable = false)
    private Instant createdDate;

    @PrePersist
    void onCreate() {
        if (createdDate == null) {
            createdDate = Instant.now();
        }
    }
}
