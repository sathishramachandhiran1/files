package com.merchantpay.common.enums;

/**
 * Central holder for all domain status/type enumerations used across modules.
 * Grouped in a single file for discoverability; each is a top-level enum.
 */
public final class Enums {
    private Enums() {
    }

    // ---------- Identity & Access ----------
    public enum UserStatus { ACTIVE, LOCKED, INACTIVE }

    // ---------- Merchant Onboarding & KYB ----------
    public enum ApplicationStatus { SUBMITTED, KYB_IN_PROGRESS, APPROVED, REJECTED, ACTIVE }

    public enum MerchantStatus { ACTIVE, SUSPENDED, TERMINATED }

    public enum RiskCategory { LOW, MEDIUM, HIGH }

    public enum SettlementFrequency { DAILY, WEEKLY, MONTHLY }

    public enum DocumentType { BUSINESS_REGISTRATION, DIRECTOR_ID, BANK_LETTER, TAX_CERTIFICATE, ADDRESS_PROOF }

    public enum VerificationStatus { PENDING, VERIFIED, REJECTED }

    // ---------- Terminal & Device ----------
    public enum TerminalType { PHYSICAL_POS, MPOS, VIRTUAL_POS, PAYMENT_LINK, QR }

    public enum TerminalStatus { ACTIVE, INACTIVE, UNDER_MAINTENANCE, DECOMMISSIONED }

    public enum TerminalEventType { DEPLOYMENT, SWAP, REPAIR, SOFTWARE_UPDATE, DECOMMISSION }

    public enum TerminalEventStatus { COMPLETED, PENDING }

    // ---------- Transaction Processing ----------
    public enum PaymentChannel { CARD, WALLET, QR, NET_BANKING, UPI }

    public enum TransactionType { PURCHASE, REFUND, VOID, PRE_AUTH, CAPTURE }

    public enum TransactionStatus { AUTHORISED, CAPTURED, DECLINED, VOIDED, REFUNDED, PENDING }

    public enum BatchStatus { OPEN, CLOSED, SUBMITTED, SETTLED }

    // ---------- Settlement & Funding ----------
    public enum SettlementRunStatus { DRAFT, PROCESSING, COMPLETED, FAILED }

    public enum MerchantSettlementStatus { PENDING, FUNDED, FAILED }

    // ---------- Chargeback & Dispute ----------
    public enum ChargebackStatus { RECEIVED, DOCUMENTS_REQUESTED, EVIDENCE_SUBMITTED, WON, LOST, REVERSED }

    public enum EvidenceType { TRANSACTION_RECEIPT, DELIVERY_PROOF, CUSTOMER_CORRESPONDENCE, SIGNED_SLIP, AUTH_LOG }

    public enum EvidenceStatus { SUBMITTED, ACCEPTED, INSUFFICIENT }

    // ---------- Fraud Monitoring ----------
    public enum FraudType { VELOCITY_BREACH, CARD_TESTING_PATTERN, HIGH_DECLINE_RATE, ANOMALOUS_AMOUNT, SUSPICIOUS_MCC }

    public enum FraudFlagStatus { OPEN, UNDER_INVESTIGATION, CLEARED, CONFIRMED, REPORTED }

    public enum RiskScoreCategory { LOW, MEDIUM, HIGH, CRITICAL }

    public enum RiskScoreStatus { CURRENT, SUPERSEDED }

    // ---------- Notifications ----------
    public enum NotificationCategory { TRANSACTION, SETTLEMENT, CHARGEBACK, FRAUD, TERMINAL, COMPLIANCE }

    public enum NotificationStatus { UNREAD, READ, DISMISSED }
}
