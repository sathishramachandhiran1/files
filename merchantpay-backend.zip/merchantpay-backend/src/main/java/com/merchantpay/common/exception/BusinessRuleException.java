package com.merchantpay.common.exception;

/**
 * Thrown when a domain/business invariant is violated (e.g. illegal state
 * transition, duplicate unique key). Maps to HTTP 409 / 422.
 */
public class BusinessRuleException extends RuntimeException {

    public BusinessRuleException(String message) {
        super(message);
    }
}
