package com.merchantpay.common.enums;

public enum Role {
    MERCHANT,
    ONBOARDING_OFFICER,
    ACQ_OPS,
    DISPUTE_ANALYST,
    FRAUD_ANALYST,
    ADMIN
}