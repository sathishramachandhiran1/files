package com.merchantpay.settlement.controller;

import com.merchantpay.common.enums.Enums.MerchantSettlementStatus;
import com.merchantpay.common.enums.Enums.SettlementRunStatus;
import com.merchantpay.common.web.PageResponse;
import com.merchantpay.settlement.dto.*;
import com.merchantpay.settlement.service.SettlementService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * Settlement run lifecycle and merchant funding line management endpoints.
 */
@RestController
@RequestMapping
@RequiredArgsConstructor
@Tag(name = "Settlement & Funding Management", description = "Settlement runs, merchant funding lines, and fund disbursement")
public class SettlementController {

    private final SettlementService settlementService;

    // ---- Settlement Runs ----

    @PostMapping("/settlement-runs")
    @PreAuthorize("hasAnyRole('ACQ_OPS','ADMIN')")
    @Operation(summary = "Create a new settlement run")
    public ResponseEntity<SettlementRunResponse> createRun(@Valid @RequestBody CreateSettlementRunRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(settlementService.createSettlementRun(req));
    }

    @GetMapping("/settlement-runs")
    @PreAuthorize("hasAnyRole('ACQ_OPS','ADMIN')")
    @Operation(summary = "List settlement runs, optionally filtered by status")
    public PageResponse<SettlementRunResponse> listRuns(@RequestParam(required = false) SettlementRunStatus status,
                                                        Pageable pageable) {
        return PageResponse.from(settlementService.listSettlementRuns(status, pageable), r -> r);
    }

    @GetMapping("/settlement-runs/{settlementId}")
    @PreAuthorize("hasAnyRole('ACQ_OPS','ADMIN')")
    @Operation(summary = "Get a settlement run by id")
    public SettlementRunResponse getRun(@PathVariable Long settlementId) {
        return settlementService.getSettlementRun(settlementId);
    }

    @PostMapping("/settlement-runs/{settlementId}/process")
    @PreAuthorize("hasAnyRole('ACQ_OPS','ADMIN')")
    @Operation(summary = "Aggregate merchant lines and complete the settlement run")
    public SettlementRunResponse processRun(@PathVariable Long settlementId) {
        return settlementService.processSettlementRun(settlementId);
    }

    // ---- Merchant Settlement Lines (nested under a run) ----

    @PostMapping("/settlement-runs/{settlementId}/merchant-settlements")
    @PreAuthorize("hasAnyRole('ACQ_OPS','ADMIN')")
    @Operation(summary = "Add a merchant funding line to a settlement run")
    public ResponseEntity<MerchantSettlementResponse> addLine(@PathVariable Long settlementId,
                                                              @Valid @RequestBody AddMerchantSettlementRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(settlementService.addMerchantSettlement(settlementId, req));
    }

    @GetMapping("/settlement-runs/{settlementId}/merchant-settlements")
    @PreAuthorize("hasAnyRole('ACQ_OPS','ADMIN')")
    @Operation(summary = "List merchant funding lines for a settlement run")
    public PageResponse<MerchantSettlementResponse> listLines(@PathVariable Long settlementId,
                                                              Pageable pageable) {
        return PageResponse.from(settlementService.listLinesByRun(settlementId, pageable), l -> l);
    }

    // ---- Merchant Settlements (flat) ----

    @GetMapping("/merchant-settlements")
    @PreAuthorize("hasAnyRole('ACQ_OPS','ADMIN') or (hasRole('MERCHANT') and #merchantId == authentication.principal.merchantId)")
    @Operation(summary = "List merchant settlement lines, optionally filtered by merchantId and/or status")
    public PageResponse<MerchantSettlementResponse> listMerchantSettlements(
            @RequestParam(required = false) Long merchantId,
            @RequestParam(required = false) MerchantSettlementStatus status,
            Pageable pageable) {
        return PageResponse.from(settlementService.listMerchantSettlements(merchantId, status, pageable), ms -> ms);
    }

    @GetMapping("/merchant-settlements/{merchantSettlementId}")
    @PreAuthorize("hasAnyRole('ACQ_OPS','ADMIN')")
    @Operation(summary = "Get a merchant settlement line by id")
    public MerchantSettlementResponse getMerchantSettlement(@PathVariable Long merchantSettlementId) {
        return settlementService.getMerchantSettlement(merchantSettlementId);
    }

    @PostMapping("/merchant-settlements/{merchantSettlementId}/fund")
    @PreAuthorize("hasAnyRole('ACQ_OPS','ADMIN')")
    @Operation(summary = "Mark a merchant settlement line as funded")
    public MerchantSettlementResponse fund(@PathVariable Long merchantSettlementId,
                                           @Valid @RequestBody FundRequest req) {
        return settlementService.markFunded(merchantSettlementId, req);
    }
}
