package com.merchantpay.settlement.dto;

import com.merchantpay.common.enums.Enums.MerchantSettlementStatus;
import com.merchantpay.settlement.domain.MerchantSettlement;
import lombok.Builder;

import java.math.BigDecimal;
import java.time.Instant;

/**
 * Read-only projection of a {@link MerchantSettlement} line.
 */
@Builder
public record MerchantSettlementResponse(
        Long merchantSettlementId,
        Long settlementId,
        Long merchantId,
        BigDecimal grossAmount,
        BigDecimal interchangeFee,
        BigDecimal schemeFee,
        BigDecimal acquirerMarkup,
        BigDecimal netFunding,
        String fundingBankRef,
        MerchantSettlementStatus status,
        Instant createdAt,
        Instant updatedAt
) {
    public static MerchantSettlementResponse from(MerchantSettlement ms) {
        return MerchantSettlementResponse.builder()
                .merchantSettlementId(ms.getMerchantSettlementId())
                .settlementId(ms.getSettlementId())
                .merchantId(ms.getMerchantId())
                .grossAmount(ms.getGrossAmount())
                .interchangeFee(ms.getInterchangeFee())
                .schemeFee(ms.getSchemeFee())
                .acquirerMarkup(ms.getAcquirerMarkup())
                .netFunding(ms.getNetFunding())
                .fundingBankRef(ms.getFundingBankRef())
                .status(ms.getStatus())
                .createdAt(ms.getCreatedAt())
                .updatedAt(ms.getUpdatedAt())
                .build();
    }
}
