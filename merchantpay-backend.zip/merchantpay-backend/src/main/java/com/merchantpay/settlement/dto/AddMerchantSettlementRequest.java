package com.merchantpay.settlement.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

/**
 * Request body for adding a merchant funding line to a settlement run.
 */
public record AddMerchantSettlementRequest(

        @NotNull(message = "merchantId is required")
        Long merchantId,

        @NotNull(message = "grossAmount is required")
        @DecimalMin(value = "0.0", inclusive = true, message = "grossAmount must be non-negative")
        BigDecimal grossAmount,

        @DecimalMin(value = "0.0", inclusive = true, message = "interchangeFee must be non-negative")
        BigDecimal interchangeFee,

        @DecimalMin(value = "0.0", inclusive = true, message = "schemeFee must be non-negative")
        BigDecimal schemeFee,

        @DecimalMin(value = "0.0", inclusive = true, message = "acquirerMarkup must be non-negative")
        BigDecimal acquirerMarkup,

        String fundingBankRef
) {
}
