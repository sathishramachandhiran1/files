package com.merchantpay.settlement.repository;

import com.merchantpay.common.enums.Enums.SettlementRunStatus;
import com.merchantpay.settlement.domain.SettlementRun;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Data access for {@link SettlementRun} entities.
 */
public interface SettlementRunRepository extends JpaRepository<SettlementRun, Long> {

    Page<SettlementRun> findByStatus(SettlementRunStatus status, Pageable pageable);
}
