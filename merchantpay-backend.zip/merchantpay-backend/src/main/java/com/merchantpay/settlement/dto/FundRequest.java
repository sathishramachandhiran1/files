package com.merchantpay.settlement.dto;

import jakarta.validation.constraints.NotBlank;

/**
 * Request body for marking a merchant settlement line as funded.
 */
public record FundRequest(

        @NotBlank(message = "fundingBankRef is required")
        String fundingBankRef
) {
}
