package com.merchantpay.settlement.dto;

import java.time.LocalDate;

/**
 * Request body for creating a new settlement run; settlement date defaults to today when absent.
 */
public record CreateSettlementRunRequest(
        LocalDate settlementDate
) {
}
