package com.merchantpay.settlement.domain;

import com.merchantpay.common.domain.BaseEntity;
import com.merchantpay.common.enums.Enums.SettlementRunStatus;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * A single settlement run aggregating funded amounts across all merchant lines for a given date.
 */
@Entity
@Table(name = "settlement_run")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SettlementRun extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "settlement_id")
    private Long settlementId;

    @Column(name = "settlement_date", nullable = false)
    @Builder.Default
    private LocalDate settlementDate = LocalDate.now();

    @Column(name = "processed_by_id")
    private Long processedById;

    @Column(name = "total_merchants_settled", nullable = false)
    @Builder.Default
    private int totalMerchantsSettled = 0;

    @Column(name = "total_gross_amount", nullable = false, precision = 19, scale = 4)
    @Builder.Default
    private BigDecimal totalGrossAmount = BigDecimal.ZERO;

    @Column(name = "total_fees", nullable = false, precision = 19, scale = 4)
    @Builder.Default
    private BigDecimal totalFees = BigDecimal.ZERO;

    @Column(name = "total_net_funded", nullable = false, precision = 19, scale = 4)
    @Builder.Default
    private BigDecimal totalNetFunded = BigDecimal.ZERO;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 16)
    @Builder.Default
    private SettlementRunStatus status = SettlementRunStatus.DRAFT;
}
