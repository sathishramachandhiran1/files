package com.merchantpay.settlement.domain;

import com.merchantpay.common.domain.BaseEntity;
import com.merchantpay.common.enums.Enums.MerchantSettlementStatus;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

/**
 * An individual merchant funding line within a {@link SettlementRun}, capturing gross amount,
 * fee breakdown, net funding, and funding bank reference.
 */
@Entity
@Table(name = "merchant_settlement", indexes = {
        @Index(name = "idx_ms_settlement_id", columnList = "settlement_id"),
        @Index(name = "idx_ms_merchant_id", columnList = "merchant_id")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MerchantSettlement extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "merchant_settlement_id")
    private Long merchantSettlementId;

    @Column(name = "settlement_id", nullable = false)
    private Long settlementId;

    @Column(name = "merchant_id", nullable = false)
    private Long merchantId;

    @Column(name = "gross_amount", nullable = false, precision = 19, scale = 4)
    private BigDecimal grossAmount;

    @Column(name = "interchange_fee", nullable = false, precision = 19, scale = 4)
    @Builder.Default
    private BigDecimal interchangeFee = BigDecimal.ZERO;

    @Column(name = "scheme_fee", nullable = false, precision = 19, scale = 4)
    @Builder.Default
    private BigDecimal schemeFee = BigDecimal.ZERO;

    @Column(name = "acquirer_markup", nullable = false, precision = 19, scale = 4)
    @Builder.Default
    private BigDecimal acquirerMarkup = BigDecimal.ZERO;

    @Column(name = "net_funding", nullable = false, precision = 19, scale = 4)
    private BigDecimal netFunding;

    @Column(name = "funding_bank_ref")
    private String fundingBankRef;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 16)
    @Builder.Default
    private MerchantSettlementStatus status = MerchantSettlementStatus.PENDING;
}
