package com.merchantpay.settlement.repository;

import com.merchantpay.common.enums.Enums.MerchantSettlementStatus;
import com.merchantpay.settlement.domain.MerchantSettlement;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Data access for {@link MerchantSettlement} entities.
 */
public interface MerchantSettlementRepository extends JpaRepository<MerchantSettlement, Long> {

    Page<MerchantSettlement> findBySettlementId(Long settlementId, Pageable pageable);

    Page<MerchantSettlement> findByMerchantId(Long merchantId, Pageable pageable);

    Page<MerchantSettlement> findByMerchantIdAndStatus(Long merchantId, MerchantSettlementStatus status, Pageable pageable);

    Page<MerchantSettlement> findByStatus(MerchantSettlementStatus status, Pageable pageable);

    java.util.List<MerchantSettlement> findBySettlementId(Long settlementId);
}
