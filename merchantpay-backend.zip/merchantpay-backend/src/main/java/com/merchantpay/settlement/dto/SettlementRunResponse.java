package com.merchantpay.settlement.dto;

import com.merchantpay.common.enums.Enums.SettlementRunStatus;
import com.merchantpay.settlement.domain.SettlementRun;
import lombok.Builder;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;

/**
 * Read-only projection of a {@link SettlementRun}.
 */
@Builder
public record SettlementRunResponse(
        Long settlementId,
        LocalDate settlementDate,
        Long processedById,
        int totalMerchantsSettled,
        BigDecimal totalGrossAmount,
        BigDecimal totalFees,
        BigDecimal totalNetFunded,
        SettlementRunStatus status,
        Instant createdAt,
        Instant updatedAt
) {
    public static SettlementRunResponse from(SettlementRun r) {
        return SettlementRunResponse.builder()
                .settlementId(r.getSettlementId())
                .settlementDate(r.getSettlementDate())
                .processedById(r.getProcessedById())
                .totalMerchantsSettled(r.getTotalMerchantsSettled())
                .totalGrossAmount(r.getTotalGrossAmount())
                .totalFees(r.getTotalFees())
                .totalNetFunded(r.getTotalNetFunded())
                .status(r.getStatus())
                .createdAt(r.getCreatedAt())
                .updatedAt(r.getUpdatedAt())
                .build();
    }
}
