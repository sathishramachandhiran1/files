package com.merchantpay.fraud.dto;

import com.merchantpay.common.enums.Enums.FraudFlagStatus;
import jakarta.validation.constraints.NotNull;

/**
 * Request payload for resolving a fraud flag; status must be CLEARED, CONFIRMED, or REPORTED.
 */
public record ResolveFlagRequest(

        @NotNull(message = "status is required")
        FraudFlagStatus status
) {
}
