package com.merchantpay.fraud.domain;

import com.merchantpay.common.domain.BaseEntity;
import com.merchantpay.common.enums.Enums.RiskScoreCategory;
import com.merchantpay.common.enums.Enums.RiskScoreStatus;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

/**
 * Stores a point-in-time computed risk score for a merchant; supersedes prior scores on update.
 */
@Entity
@Table(name = "merchant_risk_score", indexes = {
        @Index(name = "idx_merchant_risk_score_merchant_id", columnList = "merchant_id")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MerchantRiskScore extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "score_id")
    private Long scoreId;

    @Column(name = "merchant_id", nullable = false)
    private Long merchantId;

    @Column(name = "computed_date")
    @Builder.Default
    private LocalDate computedDate = LocalDate.now();

    @Column(name = "risk_score")
    private Integer riskScore;

    @Column(name = "key_factors", length = 2000)
    private String keyFactors;

    @Enumerated(EnumType.STRING)
    @Column(name = "category", length = 16)
    private RiskScoreCategory category;

    @Column(name = "review_recommendation", length = 1000)
    private String reviewRecommendation;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 16)
    @Builder.Default
    private RiskScoreStatus status = RiskScoreStatus.CURRENT;

    @PrePersist
    private void prePersist() {
        if (computedDate == null) {
            computedDate = LocalDate.now();
        }
        if (status == null) {
            status = RiskScoreStatus.CURRENT;
        }
    }
}
