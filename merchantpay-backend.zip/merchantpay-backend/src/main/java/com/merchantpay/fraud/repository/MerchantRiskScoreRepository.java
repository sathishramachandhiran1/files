package com.merchantpay.fraud.repository;

import com.merchantpay.common.enums.Enums.RiskScoreStatus;
import com.merchantpay.fraud.domain.MerchantRiskScore;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

/**
 * Data access for {@link MerchantRiskScore} records, including supersede-aware finders.
 */
public interface MerchantRiskScoreRepository extends JpaRepository<MerchantRiskScore, Long> {

    Page<MerchantRiskScore> findByMerchantId(Long merchantId, Pageable pageable);

    List<MerchantRiskScore> findByMerchantIdAndStatus(Long merchantId, RiskScoreStatus status);

    Optional<MerchantRiskScore> findFirstByMerchantIdAndStatus(Long merchantId, RiskScoreStatus status);
}
