package com.merchantpay.fraud.service;

import com.merchantpay.common.enums.Enums.FraudFlagStatus;
import com.merchantpay.common.enums.Enums.RiskScoreCategory;
import com.merchantpay.common.enums.Enums.RiskScoreStatus;
import com.merchantpay.common.exception.BusinessRuleException;
import com.merchantpay.common.exception.ResourceNotFoundException;
import com.merchantpay.fraud.domain.FraudFlag;
import com.merchantpay.fraud.domain.MerchantRiskScore;
import com.merchantpay.fraud.dto.*;
import com.merchantpay.fraud.repository.FraudFlagRepository;
import com.merchantpay.fraud.repository.MerchantRiskScoreRepository;
import com.merchantpay.iam.service.AuditService;
import com.merchantpay.security.SecurityUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.EnumSet;
import java.util.List;
import java.util.Set;

/**
 * Core business logic for fraud flag lifecycle management and merchant risk score computation.
 */
@Service
@RequiredArgsConstructor
@Transactional
public class FraudService {

    private static final Set<FraudFlagStatus> RESOLVE_STATUSES =
            EnumSet.of(FraudFlagStatus.CLEARED, FraudFlagStatus.CONFIRMED, FraudFlagStatus.REPORTED);

    private final FraudFlagRepository fraudFlagRepository;
    private final MerchantRiskScoreRepository riskScoreRepository;
    private final AuditService auditService;

    // ---------------- Fraud Flags ----------------

    public FraudFlagResponse createFlag(CreateFraudFlagRequest req) {
        FraudFlag flag = FraudFlag.builder()
                .txnId(req.txnId())
                .merchantId(req.merchantId())
                .fraudType(req.fraudType())
                .riskScore(req.riskScore())
                .status(FraudFlagStatus.OPEN)
                .build();
        flag = fraudFlagRepository.save(flag);
        auditService.record(SecurityUtils.getCurrentUserId(), "FRAUD_FLAG_CREATED", "FraudFlag", flag.getFlagId());
        return FraudFlagResponse.from(flag);
    }

    @Transactional(readOnly = true)
    public Page<FraudFlagResponse> listFlags(Long merchantId, FraudFlagStatus status,
                                             Long assignedAnalystId, Pageable pageable) {
        Page<FraudFlag> page;
        if (merchantId != null && status != null && assignedAnalystId != null) {
            page = fraudFlagRepository.findByMerchantIdAndStatusAndAssignedAnalystId(
                    merchantId, status, assignedAnalystId, pageable);
        } else if (merchantId != null && status != null) {
            page = fraudFlagRepository.findByMerchantIdAndStatus(merchantId, status, pageable);
        } else if (merchantId != null && assignedAnalystId != null) {
            page = fraudFlagRepository.findByMerchantIdAndAssignedAnalystId(merchantId, assignedAnalystId, pageable);
        } else if (status != null && assignedAnalystId != null) {
            page = fraudFlagRepository.findByStatusAndAssignedAnalystId(status, assignedAnalystId, pageable);
        } else if (merchantId != null) {
            page = fraudFlagRepository.findByMerchantId(merchantId, pageable);
        } else if (status != null) {
            page = fraudFlagRepository.findByStatus(status, pageable);
        } else if (assignedAnalystId != null) {
            page = fraudFlagRepository.findByAssignedAnalystId(assignedAnalystId, pageable);
        } else {
            page = fraudFlagRepository.findAll(pageable);
        }
        return page.map(FraudFlagResponse::from);
    }

    @Transactional(readOnly = true)
    public FraudFlagResponse getFlag(Long flagId) {
        return FraudFlagResponse.from(findFlag(flagId));
    }

    public FraudFlagResponse investigate(Long flagId) {
        FraudFlag flag = findFlag(flagId);
        if (flag.getStatus() != FraudFlagStatus.OPEN) {
            throw new BusinessRuleException(
                    "Flag must be in OPEN status to start investigation; current status: " + flag.getStatus());
        }
        flag.setStatus(FraudFlagStatus.UNDER_INVESTIGATION);
        flag = fraudFlagRepository.save(flag);
        auditService.record(SecurityUtils.getCurrentUserId(), "FRAUD_FLAG_INVESTIGATED", "FraudFlag", flagId);
        return FraudFlagResponse.from(flag);
    }

    public FraudFlagResponse assign(Long flagId, AssignFlagRequest req) {
        FraudFlag flag = findFlag(flagId);
        flag.setAssignedAnalystId(req.analystId());
        flag = fraudFlagRepository.save(flag);
        auditService.record(SecurityUtils.getCurrentUserId(), "FRAUD_FLAG_ASSIGNED", "FraudFlag", flagId);
        return FraudFlagResponse.from(flag);
    }

    public FraudFlagResponse resolve(Long flagId, ResolveFlagRequest req) {
        if (!RESOLVE_STATUSES.contains(req.status())) {
            throw new BusinessRuleException(
                    "Resolve status must be one of CLEARED, CONFIRMED, REPORTED; received: " + req.status());
        }
        FraudFlag flag = findFlag(flagId);
        if (flag.getStatus() != FraudFlagStatus.OPEN && flag.getStatus() != FraudFlagStatus.UNDER_INVESTIGATION) {
            throw new BusinessRuleException(
                    "Flag must be OPEN or UNDER_INVESTIGATION to be resolved; current status: " + flag.getStatus());
        }
        flag.setStatus(req.status());
        flag = fraudFlagRepository.save(flag);
        auditService.record(SecurityUtils.getCurrentUserId(), "FRAUD_FLAG_RESOLVED", "FraudFlag", flagId);
        return FraudFlagResponse.from(flag);
    }

    // ---------------- Risk Scores ----------------

    public MerchantRiskScoreResponse computeRiskScore(Long merchantId, ComputeRiskScoreRequest req) {
        // Supersede all existing CURRENT scores for this merchant
        List<MerchantRiskScore> current =
                riskScoreRepository.findByMerchantIdAndStatus(merchantId, RiskScoreStatus.CURRENT);
        current.forEach(s -> s.setStatus(RiskScoreStatus.SUPERSEDED));
        riskScoreRepository.saveAll(current);

        RiskScoreCategory category = (req.category() != null)
                ? req.category()
                : deriveCategory(req.riskScore());

        MerchantRiskScore score = MerchantRiskScore.builder()
                .merchantId(merchantId)
                .riskScore(req.riskScore())
                .keyFactors(req.keyFactors())
                .category(category)
                .reviewRecommendation(req.reviewRecommendation())
                .status(RiskScoreStatus.CURRENT)
                .build();
        score = riskScoreRepository.save(score);
        auditService.record(SecurityUtils.getCurrentUserId(), "RISK_SCORE_COMPUTED", "MerchantRiskScore", score.getScoreId());
        return MerchantRiskScoreResponse.from(score);
    }

    @Transactional(readOnly = true)
    public Page<MerchantRiskScoreResponse> listRiskScores(Long merchantId, Pageable pageable) {
        return riskScoreRepository.findByMerchantId(merchantId, pageable)
                .map(MerchantRiskScoreResponse::from);
    }

    @Transactional(readOnly = true)
    public MerchantRiskScoreResponse getCurrentRiskScore(Long merchantId) {
        return riskScoreRepository.findFirstByMerchantIdAndStatus(merchantId, RiskScoreStatus.CURRENT)
                .map(MerchantRiskScoreResponse::from)
                .orElseThrow(() -> new ResourceNotFoundException("MerchantRiskScore (CURRENT)", merchantId));
    }

    // ---------------- helpers ----------------

    private FraudFlag findFlag(Long flagId) {
        return fraudFlagRepository.findById(flagId)
                .orElseThrow(() -> new ResourceNotFoundException("FraudFlag", flagId));
    }

    private static RiskScoreCategory deriveCategory(int score) {
        if (score < 40) return RiskScoreCategory.LOW;
        if (score < 60) return RiskScoreCategory.MEDIUM;
        if (score < 80) return RiskScoreCategory.HIGH;
        return RiskScoreCategory.CRITICAL;
    }
}
