package com.merchantpay.fraud.dto;

import jakarta.validation.constraints.NotNull;

/**
 * Request payload for assigning a fraud flag to an analyst.
 */
public record AssignFlagRequest(

        @NotNull(message = "analystId is required")
        Long analystId
) {
}
