package com.merchantpay.fraud.dto;

import com.merchantpay.common.enums.Enums.RiskScoreCategory;
import com.merchantpay.common.enums.Enums.RiskScoreStatus;
import com.merchantpay.fraud.domain.MerchantRiskScore;
import lombok.Builder;

import java.time.LocalDate;

/**
 * Read-model representation of a {@link MerchantRiskScore}.
 */
@Builder
public record MerchantRiskScoreResponse(
        Long scoreId,
        Long merchantId,
        LocalDate computedDate,
        Integer riskScore,
        String keyFactors,
        RiskScoreCategory category,
        String reviewRecommendation,
        RiskScoreStatus status
) {
    public static MerchantRiskScoreResponse from(MerchantRiskScore s) {
        return MerchantRiskScoreResponse.builder()
                .scoreId(s.getScoreId())
                .merchantId(s.getMerchantId())
                .computedDate(s.getComputedDate())
                .riskScore(s.getRiskScore())
                .keyFactors(s.getKeyFactors())
                .category(s.getCategory())
                .reviewRecommendation(s.getReviewRecommendation())
                .status(s.getStatus())
                .build();
    }
}
