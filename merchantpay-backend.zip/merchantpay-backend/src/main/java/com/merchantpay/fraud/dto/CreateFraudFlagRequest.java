package com.merchantpay.fraud.dto;

import com.merchantpay.common.enums.Enums.FraudType;
import jakarta.validation.constraints.NotNull;

/**
 * Request payload for raising a new fraud flag.
 */
public record CreateFraudFlagRequest(

        Long txnId,

        @NotNull(message = "merchantId is required")
        Long merchantId,

        @NotNull(message = "fraudType is required")
        FraudType fraudType,

        Integer riskScore
) {
}
