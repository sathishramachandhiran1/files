package com.merchantpay.fraud.dto;

import com.merchantpay.common.enums.Enums.FraudFlagStatus;
import com.merchantpay.common.enums.Enums.FraudType;
import com.merchantpay.fraud.domain.FraudFlag;
import lombok.Builder;

import java.time.Instant;

/**
 * Read-model representation of a {@link FraudFlag}.
 */
@Builder
public record FraudFlagResponse(
        Long flagId,
        Long txnId,
        Long merchantId,
        FraudType fraudType,
        Integer riskScore,
        Instant flaggedDate,
        Long assignedAnalystId,
        FraudFlagStatus status
) {
    public static FraudFlagResponse from(FraudFlag f) {
        return FraudFlagResponse.builder()
                .flagId(f.getFlagId())
                .txnId(f.getTxnId())
                .merchantId(f.getMerchantId())
                .fraudType(f.getFraudType())
                .riskScore(f.getRiskScore())
                .flaggedDate(f.getFlaggedDate())
                .assignedAnalystId(f.getAssignedAnalystId())
                .status(f.getStatus())
                .build();
    }
}
