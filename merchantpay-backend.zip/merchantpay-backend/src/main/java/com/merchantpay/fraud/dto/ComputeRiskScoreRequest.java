package com.merchantpay.fraud.dto;

import com.merchantpay.common.enums.Enums.RiskScoreCategory;
import jakarta.validation.constraints.NotNull;

/**
 * Request payload for computing and recording a new merchant risk score.
 */
public record ComputeRiskScoreRequest(

        @NotNull(message = "riskScore is required")
        Integer riskScore,

        String keyFactors,

        /** When omitted the category is derived automatically from the score. */
        RiskScoreCategory category,

        String reviewRecommendation
) {
}
