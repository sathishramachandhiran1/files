# MerchantPay API Documentation

**Base URL:** `http://localhost:8080/api`
**Auth:** Bearer JWT (`Authorization: Bearer <accessToken>`) on all endpoints except `/auth/*`.
**Content-Type:** `application/json`
**Live, generated docs:** `/swagger-ui.html` · OpenAPI JSON: `/v3/api-docs`

## Conventions

- **Pagination** — list endpoints accept `?page=0&size=20&sort=field,asc`. Responses use:
  ```json
  { "content": [ ... ], "page": 0, "size": 20, "totalElements": 42, "totalPages": 3, "last": false }
  ```
- **Errors** — uniform shape:
  ```json
  {
    "timestamp": "2026-06-10T10:15:30Z",
    "status": 422,
    "error": "Unprocessable Entity",
    "message": "KYB can only start from SUBMITTED state",
    "path": "/api/applications/5/start-kyb",
    "fieldErrors": [ { "field": "email", "rejectedValue": "x", "message": "must be a well-formed email address" } ]
  }
  ```
  | Status | Meaning |
  |--------|---------|
  | 400 | Validation failure / malformed request |
  | 401 | Missing/invalid/expired token, or bad credentials |
  | 403 | Authenticated but not authorised (RBAC) |
  | 404 | Resource not found |
  | 409 | Duplicate / data integrity conflict |
  | 422 | Business-rule violation (e.g. illegal status transition) |

- **Roles:** `MERCHANT`, `ONBOARDING_OFFICER`, `ACQ_OPS`, `DISPUTE_ANALYST`, `FRAUD_ANALYST`, `ADMIN`.

---

## 1. Authentication — `/auth` (public)

| Method | Path | Description |
|--------|------|-------------|
| POST | `/auth/register` | Register a user, returns tokens. **201** |
| POST | `/auth/login` | Authenticate by email/password, returns tokens. |
| POST | `/auth/refresh` | Exchange a refresh token for new tokens. |

**POST /auth/register**
```json
{
  "name": "Jane Merchant",
  "role": "MERCHANT",
  "email": "jane@shop.com",
  "phone": "+15551234567",
  "password": "Str0ngPass!",
  "merchantId": 10
}
```
`role` ∈ the six roles. `merchantId` is required only for `MERCHANT` users (scopes their access).

**POST /auth/login** → request `{ "email", "password" }`; response:
```json
{
  "accessToken": "eyJhbGciOi...",
  "refreshToken": "eyJhbGciOi...",
  "tokenType": "Bearer",
  "expiresInSeconds": 3600,
  "user": { "userId": 1, "name": "...", "role": "ADMIN", "email": "...", "merchantId": null, "status": "ACTIVE" }
}
```

**POST /auth/refresh** → `{ "refreshToken": "..." }` → same `AuthResponse` shape.

---

## 2. Users & Audit — `/users`, `/audit-logs`

| Method | Path | Roles | Description |
|--------|------|-------|-------------|
| GET | `/users/me` | any authenticated | Current user's profile. |
| GET | `/users` | ADMIN | List users (paged). |
| GET | `/users/{userId}` | ADMIN | Get a user. |
| PATCH | `/users/{userId}/status` | ADMIN | Set status. Body: `{ "status": "ACTIVE\|LOCKED\|INACTIVE" }` |
| GET | `/audit-logs` | ADMIN | Audit trail (paged). Filters: `entityType`, `recordId`. |

---

## 3. Merchant Onboarding & KYB — `/applications`, `/merchants`, KYB docs

| Method | Path | Roles | Description |
|--------|------|-------|-------------|
| POST | `/applications` | ONBOARDING_OFFICER, ADMIN | Submit application. **201** |
| GET | `/applications` | ONBOARDING_OFFICER, ADMIN | List (filter `?status=`). |
| GET | `/applications/{appId}` | ONBOARDING_OFFICER, ADMIN | Get one. |
| POST | `/applications/{appId}/start-kyb` | ONBOARDING_OFFICER, ADMIN | `SUBMITTED → KYB_IN_PROGRESS`. |
| POST | `/applications/{appId}/reject` | ONBOARDING_OFFICER, ADMIN | `→ REJECTED`. |
| POST | `/applications/{appId}/approve` | ONBOARDING_OFFICER, ADMIN | Approve & provision merchant. **201** |
| GET | `/merchants` | ONBOARDING_OFFICER, ACQ_OPS, ADMIN | List (filter `?status=`). |
| GET | `/merchants/{merchantId}` | staff, or owning MERCHANT | Get merchant. |
| PATCH | `/merchants/{merchantId}` | ONBOARDING_OFFICER, ADMIN | Update risk/settlement/fee/status. |
| POST | `/merchants/{merchantId}/kyb-documents` | ONBOARDING_OFFICER, ADMIN | Upload KYB doc. **201** |
| GET | `/merchants/{merchantId}/kyb-documents` | ONBOARDING_OFFICER, ADMIN | List docs. |
| PATCH | `/kyb-documents/{docId}/verify` | ONBOARDING_OFFICER, ADMIN | Set verification status. |

**POST /applications**
```json
{
  "businessName": "Acme Retail Ltd",
  "registrationNumber": "REG-99281",
  "mcc": "5411",
  "businessType": "RETAIL",
  "ownerName": "John Owner",
  "nationalIdRef": "NID-123",
  "settlementBankAccountRef": "BANK-ACC-555"
}
```
**POST /applications/{appId}/approve**
```json
{ "merchantCode": "MERCH-0001", "riskCategory": "LOW", "settlementFrequency": "DAILY", "feeScheduleId": 1 }
```
**PATCH /merchants/{merchantId}** (partial; null fields unchanged)
```json
{ "riskCategory": "MEDIUM", "settlementFrequency": "WEEKLY", "feeScheduleId": 2, "status": "ACTIVE" }
```
**POST /merchants/{merchantId}/kyb-documents**
```json
{ "documentType": "BUSINESS_REGISTRATION", "filePath": "s3://kyb/acme/reg.pdf" }
```
`documentType` ∈ `BUSINESS_REGISTRATION, DIRECTOR_ID, BANK_LETTER, TAX_CERTIFICATE, ADDRESS_PROOF`.
**PATCH /kyb-documents/{docId}/verify** → `{ "verificationStatus": "VERIFIED" }` (`PENDING|VERIFIED|REJECTED`).

---

## 4. Terminal & Device Management — `/terminals`

| Method | Path | Roles | Description |
|--------|------|-------|-------------|
| POST | `/terminals` | ACQ_OPS, ADMIN | Provision terminal (unique serial). **201** |
| GET | `/terminals` | staff, or owning MERCHANT | List (filters `?merchantId=&status=`). |
| GET | `/terminals/{terminalId}` | staff, or owning MERCHANT | Get one. |
| PATCH | `/terminals/{terminalId}` | ACQ_OPS, ADMIN | Update status/location/model (partial). |
| POST | `/terminals/{terminalId}/decommission` | ACQ_OPS, ADMIN | Set `DECOMMISSIONED` + log event. |
| POST | `/terminals/{terminalId}/events` | ACQ_OPS, ADMIN | Record a terminal event. **201** |
| GET | `/terminals/{terminalId}/events` | ACQ_OPS, ADMIN | List events. |

**POST /terminals**
```json
{
  "merchantId": 10,
  "terminalType": "PHYSICAL_POS",
  "serialNumber": "SN-AB12345",
  "model": "Ingenico Move 5000",
  "locationDescription": "Store #4 — checkout 2"
}
```
`terminalType` ∈ `PHYSICAL_POS, MPOS, VIRTUAL_POS, PAYMENT_LINK, QR`. `status` ∈ `ACTIVE, INACTIVE, UNDER_MAINTENANCE, DECOMMISSIONED`.

**POST /terminals/{terminalId}/events**
```json
{ "eventType": "SOFTWARE_UPDATE", "performedById": 3, "notes": "Firmware v2.3", "status": "COMPLETED" }
```
`eventType` ∈ `DEPLOYMENT, SWAP, REPAIR, SOFTWARE_UPDATE, DECOMMISSION`. `status` ∈ `COMPLETED, PENDING`.

---

## 5. Transaction Processing & Authorisation — `/transactions`, `/batches`

| Method | Path | Roles | Description |
|--------|------|-------|-------------|
| POST | `/transactions` | ACQ_OPS, ADMIN | Record a transaction. **201** |
| GET | `/transactions` | staff, or owning MERCHANT | List (filters `?merchantId=&status=`). |
| GET | `/transactions/{txnId}` | ACQ_OPS, ADMIN | Get one. |
| POST | `/transactions/{txnId}/capture` | ACQ_OPS, ADMIN | `AUTHORISED → CAPTURED`. |
| POST | `/transactions/{txnId}/void` | ACQ_OPS, ADMIN | `AUTHORISED/PENDING → VOIDED`. |
| POST | `/transactions/{txnId}/refund` | ACQ_OPS, ADMIN | `CAPTURED → REFUNDED`. |
| POST | `/batches` | ACQ_OPS, ADMIN | Open a batch. **201** |
| GET | `/batches` | ACQ_OPS, ADMIN | List (filters `?merchantId=&status=`). |
| GET | `/batches/{batchId}` | ACQ_OPS, ADMIN | Get one. |
| POST | `/batches/{batchId}/close` | ACQ_OPS, ADMIN | `OPEN → CLOSED`. |
| POST | `/batches/{batchId}/submit` | ACQ_OPS, ADMIN | `CLOSED → SUBMITTED`. |

**POST /transactions** — *only the card BIN is accepted; never a full PAN.*
```json
{
  "merchantId": 10,
  "terminalId": 7,
  "paymentChannel": "CARD",
  "transactionType": "PURCHASE",
  "amount": 129.99,
  "currency": "USD",
  "cardBin": "411111",
  "authorisationCode": "A1B2C3",
  "status": "AUTHORISED"
}
```
`paymentChannel` ∈ `CARD, WALLET, QR, NET_BANKING, UPI`. `transactionType` ∈ `PURCHASE, REFUND, VOID, PRE_AUTH, CAPTURE`.
`status` ∈ `AUTHORISED, CAPTURED, DECLINED, VOIDED, REFUNDED, PENDING`.

**POST /batches** → `{ "merchantId": 10, "terminalId": 7, "batchDate": "2026-06-10" }`. Batch status ∈ `OPEN, CLOSED, SUBMITTED, SETTLED`.

---

## 6. Settlement & Funding — `/settlement-runs`, `/merchant-settlements`

| Method | Path | Roles | Description |
|--------|------|-------|-------------|
| POST | `/settlement-runs` | ACQ_OPS, ADMIN | Create run (DRAFT). **201** |
| GET | `/settlement-runs` | ACQ_OPS, ADMIN | List (filter `?status=`). |
| GET | `/settlement-runs/{settlementId}` | ACQ_OPS, ADMIN | Get one. |
| POST | `/settlement-runs/{settlementId}/process` | ACQ_OPS, ADMIN | Aggregate lines → `COMPLETED`. |
| POST | `/settlement-runs/{settlementId}/merchant-settlements` | ACQ_OPS, ADMIN | Add a merchant line. **201** |
| GET | `/settlement-runs/{settlementId}/merchant-settlements` | ACQ_OPS, ADMIN | List lines for a run. |
| GET | `/merchant-settlements` | staff, or owning MERCHANT | List (filters `?merchantId=&status=`). |
| GET | `/merchant-settlements/{merchantSettlementId}` | ACQ_OPS, ADMIN | Get one. |
| POST | `/merchant-settlements/{merchantSettlementId}/fund` | ACQ_OPS, ADMIN | `PENDING → FUNDED`. |

**POST /settlement-runs** → `{ "settlementDate": "2026-06-10" }` (optional; defaults today).

**POST /settlement-runs/{id}/merchant-settlements** — `netFunding` is computed server-side as
`grossAmount − (interchangeFee + schemeFee + acquirerMarkup)`:
```json
{ "merchantId": 10, "grossAmount": 10000.00, "interchangeFee": 120.00, "schemeFee": 30.00, "acquirerMarkup": 50.00, "fundingBankRef": "WIRE-778" }
```
**POST /merchant-settlements/{id}/fund** → `{ "fundingBankRef": "WIRE-778" }` (required).
Run status ∈ `DRAFT, PROCESSING, COMPLETED, FAILED`. Line status ∈ `PENDING, FUNDED, FAILED`.

---

## 7. Chargeback & Dispute — `/chargeback-cases`, `/evidence`

| Method | Path | Roles | Description |
|--------|------|-------|-------------|
| POST | `/chargeback-cases` | DISPUTE_ANALYST, ADMIN | Log a chargeback. **201** |
| GET | `/chargeback-cases` | staff, or owning MERCHANT | List (filters `?merchantId=&status=&assignedAnalystId=`). |
| GET | `/chargeback-cases/{caseId}` | DISPUTE_ANALYST, ADMIN | Get one. |
| POST | `/chargeback-cases/{caseId}/request-documents` | DISPUTE_ANALYST, ADMIN | `RECEIVED → DOCUMENTS_REQUESTED`. |
| POST | `/chargeback-cases/{caseId}/assign` | DISPUTE_ANALYST, ADMIN | Assign analyst. |
| POST | `/chargeback-cases/{caseId}/resolve` | DISPUTE_ANALYST, ADMIN | `→ WON/LOST/REVERSED`. |
| POST | `/chargeback-cases/{caseId}/evidence` | DISPUTE_ANALYST, ADMIN | Submit evidence (auto `EVIDENCE_SUBMITTED`). **201** |
| GET | `/chargeback-cases/{caseId}/evidence` | DISPUTE_ANALYST, ADMIN | List evidence. |
| PATCH | `/evidence/{evidenceId}` | DISPUTE_ANALYST, ADMIN | Update evidence status. |

**POST /chargeback-cases** (`responseDeadline` defaults to `receivedDate + 30 days`):
```json
{ "txnId": 501, "merchantId": 10, "reasonCode": "10.4", "claimAmount": 129.99, "responseDeadline": "2026-07-10" }
```
**POST .../assign** → `{ "analystId": 4 }`. **POST .../resolve** → `{ "status": "WON" }` (`WON|LOST|REVERSED`).
**POST .../evidence** → `{ "evidenceType": "TRANSACTION_RECEIPT", "filePath": "s3://disputes/501/receipt.pdf" }`
(`evidenceType` ∈ `TRANSACTION_RECEIPT, DELIVERY_PROOF, CUSTOMER_CORRESPONDENCE, SIGNED_SLIP, AUTH_LOG`).
**PATCH /evidence/{id}** → `{ "status": "ACCEPTED" }` (`SUBMITTED|ACCEPTED|INSUFFICIENT`).
Case status ∈ `RECEIVED, DOCUMENTS_REQUESTED, EVIDENCE_SUBMITTED, WON, LOST, REVERSED`.

---

## 8. Fraud Monitoring & Risk — `/fraud-flags`, `/merchants/{id}/risk-scores`

| Method | Path | Roles | Description |
|--------|------|-------|-------------|
| POST | `/fraud-flags` | FRAUD_ANALYST, ADMIN | Raise a fraud flag. **201** |
| GET | `/fraud-flags` | FRAUD_ANALYST, ADMIN | List (filters `?merchantId=&status=&assignedAnalystId=`). |
| GET | `/fraud-flags/{flagId}` | FRAUD_ANALYST, ADMIN | Get one. |
| POST | `/fraud-flags/{flagId}/investigate` | FRAUD_ANALYST, ADMIN | `OPEN → UNDER_INVESTIGATION`. |
| POST | `/fraud-flags/{flagId}/assign` | FRAUD_ANALYST, ADMIN | Assign analyst. |
| POST | `/fraud-flags/{flagId}/resolve` | FRAUD_ANALYST, ADMIN | `→ CLEARED/CONFIRMED/REPORTED`. |
| POST | `/merchants/{merchantId}/risk-scores` | FRAUD_ANALYST, ADMIN | Compute score (supersedes prior). **201** |
| GET | `/merchants/{merchantId}/risk-scores` | FRAUD_ANALYST, ADMIN | Score history. |
| GET | `/merchants/{merchantId}/risk-scores/current` | FRAUD_ANALYST, ADMIN | Current score (404 if none). |

**POST /fraud-flags**
```json
{ "txnId": 501, "merchantId": 10, "fraudType": "VELOCITY_BREACH", "riskScore": 82 }
```
`fraudType` ∈ `VELOCITY_BREACH, CARD_TESTING_PATTERN, HIGH_DECLINE_RATE, ANOMALOUS_AMOUNT, SUSPICIOUS_MCC`.
Flag status ∈ `OPEN, UNDER_INVESTIGATION, CLEARED, CONFIRMED, REPORTED`.
**POST .../resolve** → `{ "status": "CONFIRMED" }`. **POST .../assign** → `{ "analystId": 5 }`.

**POST /merchants/{id}/risk-scores** (category auto-derived from score if omitted: `<40 LOW, <60 MEDIUM, <80 HIGH, else CRITICAL`):
```json
{ "riskScore": 72, "keyFactors": "High chargeback ratio; new MCC", "category": "HIGH", "reviewRecommendation": "Manual review" }
```
Category ∈ `LOW, MEDIUM, HIGH, CRITICAL`. Score status ∈ `CURRENT, SUPERSEDED`.

---

## 9. Notifications & Alerts — `/notifications`

| Method | Path | Roles | Description |
|--------|------|-------|-------------|
| POST | `/notifications` | ADMIN, ACQ_OPS, DISPUTE_ANALYST, FRAUD_ANALYST | Create for a target user. **201** |
| GET | `/notifications` | any authenticated | Current user's notifications (filter `?status=`). |
| GET | `/notifications/unread-count` | any authenticated | `{ "unreadCount": 3 }`. |
| POST | `/notifications/{notificationId}/read` | owner | Mark read. |
| POST | `/notifications/{notificationId}/dismiss` | owner | Dismiss. |

**POST /notifications**
```json
{ "userId": 10, "message": "Settlement WIRE-778 credited", "category": "SETTLEMENT" }
```
`category` ∈ `TRANSACTION, SETTLEMENT, CHARGEBACK, FRAUD, TERMINAL, COMPLIANCE`. Status ∈ `UNREAD, READ, DISMISSED`.
A user only ever sees/mutates their own notifications.

---

## Appendix — Quick start with curl

```bash
# 1. Log in as the seeded admin
TOKEN=$(curl -s -X POST http://localhost:8080/api/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"email":"admin@merchantpay.local","password":"Admin@12345"}' | jq -r .accessToken)

# 2. Create a merchant application
curl -s -X POST http://localhost:8080/api/applications \
  -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d '{"businessName":"Acme Retail Ltd","registrationNumber":"REG-99281","mcc":"5411"}'

# 3. List merchants
curl -s http://localhost:8080/api/merchants -H "Authorization: Bearer $TOKEN"
```
