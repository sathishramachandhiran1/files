package com.merchantpay.transaction.service;

import com.merchantpay.common.enums.Enums.BatchStatus;

import com.merchantpay.common.enums.Enums.TransactionStatus;

import com.merchantpay.common.exception.BusinessRuleException;

import com.merchantpay.common.exception.ResourceNotFoundException;

import com.merchantpay.fraud.service.FraudService;
import com.merchantpay.iam.service.AuditService;

import com.merchantpay.security.SecurityUtils;

import com.merchantpay.transaction.domain.PaymentTransaction;

import com.merchantpay.transaction.domain.TransactionBatch;

import com.merchantpay.transaction.dto.*;

import com.merchantpay.transaction.repository.PaymentTransactionRepository;

import com.merchantpay.transaction.repository.TransactionBatchRepository;

import lombok.RequiredArgsConstructor;

import org.springframework.data.domain.Page;

import org.springframework.data.domain.Pageable;

import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;

/**

 * Core business logic for transaction recording, lifecycle transitions, and batch management.

 */

@Service

@RequiredArgsConstructor

public class TransactionService {

    private final PaymentTransactionRepository transactionRepository;

    private final TransactionBatchRepository batchRepository;

    private final AuditService auditService;
    private final FraudService fraudService;

    // -------------------- Transactions --------------------
    @Transactional
    public TransactionResponse createTransaction(CreateTransactionRequest req) {

        TransactionBatch activeBatch = batchRepository.findFirstByMerchantIdAndTerminalIdAndStatus(

                        req.merchantId(), req.terminalId(), BatchStatus.OPEN)

                .orElseThrow(() -> new BusinessRuleException(

                        "No active OPEN batch found for Merchant ID: " + req.merchantId() +

                                " and Terminal ID: " + req.terminalId() + ". Transactions cannot be processed without an open batch."));


        PaymentTransaction txn = PaymentTransaction.builder()

                .merchantId(req.merchantId())

                .terminalId(req.terminalId())

                .batchId(activeBatch.getBatchId())

                .paymentChannel(req.paymentChannel())

                .transactionType(req.transactionType())

                .amount(req.amount())

                .currency(req.currency() != null ? req.currency() : "USD")

                .cardBin(req.cardBin())

                .authorisationCode(req.authorisationCode())

                .status(req.status() != null ? req.status() : TransactionStatus.PENDING)

                .build();

        txn = transactionRepository.save(txn);
        fraudService.evaluateTransaction(txn);

        activeBatch.setTotalTransactions(activeBatch.getTotalTransactions() + 1);

        activeBatch.setTotalAmount(activeBatch.getTotalAmount().add(req.amount()));

        batchRepository.save(activeBatch);

        auditService.record(SecurityUtils.getCurrentUserId(), "TRANSACTION_CREATED", "PaymentTransaction", txn.getTxnId());

        return TransactionResponse.from(txn);

    }

    @Transactional(readOnly = true)

    public Page<TransactionResponse> listTransactions(Long merchantId, TransactionStatus status, Pageable pageable) {

        Page<PaymentTransaction> page;

        if (merchantId != null && status != null) {

            page = transactionRepository.findByMerchantIdAndStatus(merchantId, status, pageable);

        } else if (merchantId != null) {

            page = transactionRepository.findByMerchantId(merchantId, pageable);

        } else if (status != null) {

            page = transactionRepository.findByStatus(status, pageable);

        } else {

            page = transactionRepository.findAll(pageable);

        }

        return page.map(TransactionResponse::from);

    }

    @Transactional(readOnly = true)

    public TransactionResponse getTransaction(Long txnId) {

        return TransactionResponse.from(findTransaction(txnId));

    }

    /**

     * Transitions a transaction from AUTHORISED to CAPTURED.

     */

    @Transactional

    public TransactionResponse captureTransaction(Long txnId) {

        PaymentTransaction txn = findTransaction(txnId);

        requireStatus(txn, TransactionStatus.AUTHORISED, "capture");

        txn.setStatus(TransactionStatus.CAPTURED);

        txn = transactionRepository.save(txn);

        auditService.record(SecurityUtils.getCurrentUserId(), "TRANSACTION_CAPTURED", "PaymentTransaction", txnId);

        return TransactionResponse.from(txn);

    }

    /**

     * Transitions a transaction from AUTHORISED or PENDING to VOIDED.

     * Deducts the transaction amount and count from its associated batch if the batch is still OPEN.

     */

    @Transactional

    public TransactionResponse voidTransaction(Long txnId) {

        PaymentTransaction txn = findTransaction(txnId);

        TransactionStatus current = txn.getStatus();

        if (current == TransactionStatus.CAPTURED

                || current == TransactionStatus.REFUNDED

                || current == TransactionStatus.VOIDED) {

            throw new BusinessRuleException(

                    "Transaction " + txnId + " in status " + current + " cannot be voided");

        }

        txn.setStatus(TransactionStatus.VOIDED);

        txn = transactionRepository.save(txn);

        // Deduct from the associated batch if a batch link exists

        if (txn.getBatchId() != null) {

            TransactionBatch batch = findBatch(txn.getBatchId());

            if (batch.getStatus() == BatchStatus.OPEN) {

                batch.setTotalTransactions(Math.max(0, batch.getTotalTransactions() - 1));

                batch.setTotalAmount(batch.getTotalAmount().subtract(txn.getAmount()));

                batchRepository.save(batch);

            }

        }

        auditService.record(SecurityUtils.getCurrentUserId(), "TRANSACTION_VOIDED", "PaymentTransaction", txnId);

        return TransactionResponse.from(txn);

    }

    /**

     * Transitions a transaction from CAPTURED to REFUNDED.

     * Deducts the transaction amount and count from its associated batch if the batch is still OPEN.

     */

    @Transactional

    public TransactionResponse refundTransaction(Long txnId) {

        PaymentTransaction txn = findTransaction(txnId);

        requireStatus(txn, TransactionStatus.CAPTURED, "refund");

        txn.setStatus(TransactionStatus.REFUNDED);

        txn = transactionRepository.save(txn);

        // Deduct from the associated batch if a batch link exists

        if (txn.getBatchId() != null) {

            TransactionBatch batch = findBatch(txn.getBatchId());

            if (batch.getStatus() == BatchStatus.OPEN) {

                batch.setTotalTransactions(Math.max(0, batch.getTotalTransactions() - 1));

                batch.setTotalAmount(batch.getTotalAmount().subtract(txn.getAmount()));

                batchRepository.save(batch);

            }

        }

        auditService.record(SecurityUtils.getCurrentUserId(), "TRANSACTION_REFUNDED", "PaymentTransaction", txnId);

        return TransactionResponse.from(txn);

    }

    // -------------------- Batches --------------------

    /**

     * Opens a new transaction batch for a merchant terminal.

     */

    @Transactional

    public BatchResponse createBatch(CreateBatchRequest req) {

        TransactionBatch batch = TransactionBatch.builder()

                .merchantId(req.merchantId())

                .terminalId(req.terminalId())

                .batchDate(req.batchDate() != null ? req.batchDate() : java.time.LocalDate.now())

                .build();

        batch = batchRepository.save(batch);

        auditService.record(SecurityUtils.getCurrentUserId(), "BATCH_CREATED", "TransactionBatch", batch.getBatchId());

        return BatchResponse.from(batch);

    }

    @Transactional(readOnly = true)

    public Page<BatchResponse> listBatches(Long merchantId, BatchStatus status, Pageable pageable) {

        Page<TransactionBatch> page;

        if (merchantId != null && status != null) {

            page = batchRepository.findByMerchantIdAndStatus(merchantId, status, pageable);

        } else if (merchantId != null) {

            page = batchRepository.findByMerchantId(merchantId, pageable);

        } else if (status != null) {

            page = batchRepository.findByStatus(status, pageable);

        } else {

            page = batchRepository.findAll(pageable);

        }

        return page.map(BatchResponse::from);

    }

    @Transactional(readOnly = true)

    public BatchResponse getBatch(Long batchId) {

        return BatchResponse.from(findBatch(batchId));

    }

    /**

     * Transitions a batch from OPEN to CLOSED.

     */

    @Transactional

    public BatchResponse closeBatch(Long batchId) {

        TransactionBatch batch = findBatch(batchId);

        requireBatchStatus(batch, BatchStatus.OPEN, "close");

        batch.setStatus(BatchStatus.CLOSED);

        batch = batchRepository.save(batch);

        auditService.record(SecurityUtils.getCurrentUserId(), "BATCH_CLOSED", "TransactionBatch", batchId);

        return BatchResponse.from(batch);

    }

    /**

     * Transitions a batch from CLOSED to SUBMITTED.

     */

    @Transactional

    public BatchResponse submitBatch(Long batchId) {

        TransactionBatch batch = findBatch(batchId);

        requireBatchStatus(batch, BatchStatus.CLOSED, "submit");

        batch.setStatus(BatchStatus.SUBMITTED);

        batch = batchRepository.save(batch);

        auditService.record(SecurityUtils.getCurrentUserId(), "BATCH_SUBMITTED", "TransactionBatch", batchId);

        return BatchResponse.from(batch);

    }

    // -------------------- Helpers --------------------

    private PaymentTransaction findTransaction(Long txnId) {

        return transactionRepository.findById(txnId)

                .orElseThrow(() -> new ResourceNotFoundException("PaymentTransaction", txnId));

    }

    private TransactionBatch findBatch(Long batchId) {

        return batchRepository.findById(batchId)

                .orElseThrow(() -> new ResourceNotFoundException("TransactionBatch", batchId));

    }

    private void requireStatus(PaymentTransaction txn, TransactionStatus required, String operation) {

        if (txn.getStatus() != required) {

            throw new BusinessRuleException(

                    "Transaction " + txn.getTxnId() + " must be in status " + required

                            + " to " + operation + ", but is " + txn.getStatus());

        }

    }

    private void requireBatchStatus(TransactionBatch batch, BatchStatus required, String operation) {

        if (batch.getStatus() != required) {

            throw new BusinessRuleException(

                    "Batch " + batch.getBatchId() + " must be in status " + required

                            + " to " + operation + ", but is " + batch.getStatus());

        }

    }

}
