
package com.merchantpay.transaction.domain;
import com.merchantpay.common.domain.BaseEntity;
import com.merchantpay.common.enums.Enums.PaymentChannel;
import com.merchantpay.common.enums.Enums.TransactionStatus;
import com.merchantpay.common.enums.Enums.TransactionType;
import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.Instant;

/**

 * Records a single payment event (purchase, refund, void, pre-auth, or capture)

 * for a merchant terminal. Only the card BIN (first 6 digits) is ever persisted.

 */

@Entity
@Table(
        name = "payment_transaction",
        indexes = {
                @Index(name = "idx_pt_merchant_id", columnList = "merchant_id"),
                @Index(name = "idx_pt_terminal_id", columnList = "terminal_id"),
                @Index(name = "idx_pt_batch_id", columnList = "batch_id")
        }
)

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PaymentTransaction extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "txn_id")
    private Long txnId;
    @Column(name = "merchant_id", nullable = false)
    private Long merchantId;
    @Column(name = "terminal_id")
    private Long terminalId;
    @Column(name = "batch_id")
    private Long batchId;
    @Enumerated(EnumType.STRING)
    @Column(name = "payment_channel", nullable = false, length = 16)
    private PaymentChannel paymentChannel;
    @Enumerated(EnumType.STRING)
    @Column(name = "transaction_type", nullable = false, length = 16)
    private TransactionType transactionType;
    @Column(name = "amount", nullable = false, precision = 19, scale = 4)
    private BigDecimal amount;
    @Column(name = "currency", length = 3)
    @Builder.Default
    private String currency = "USD";

    @Column(name = "card_bin", length = 6)
    private String cardBin;
    @Column(name = "authorisation_code")
    private String authorisationCode;
    @Column(name = "transaction_date_time")
    @Builder.Default
    private Instant transactionDateTime = Instant.now();
    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 16)
    @Builder.Default
    private TransactionStatus status = TransactionStatus.PENDING;

    @PrePersist
    private void prePersist() {
        if (transactionDateTime == null) {
            transactionDateTime = Instant.now();
        }
        if (status == null) {
            status = TransactionStatus.PENDING;
        }
        if (currency == null) {
            currency = "USD";
        }
    }
}