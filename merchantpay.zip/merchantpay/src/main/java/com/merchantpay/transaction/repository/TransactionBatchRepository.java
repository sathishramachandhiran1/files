package com.merchantpay.transaction.repository;
import com.merchantpay.common.enums.Enums.BatchStatus;
import com.merchantpay.transaction.domain.TransactionBatch;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
/**

 * Data access for {@link TransactionBatch} entities.

 */
public interface TransactionBatchRepository extends JpaRepository<TransactionBatch, Long> {

    Optional<TransactionBatch> findFirstByMerchantIdAndTerminalIdAndStatus(
            Long merchantId, Long terminalId, BatchStatus status);
    Page<TransactionBatch> findByMerchantId(Long merchantId, Pageable pageable);
    Page<TransactionBatch> findByStatus(BatchStatus status, Pageable pageable);
    Page<TransactionBatch> findByMerchantIdAndStatus(Long merchantId, BatchStatus status, Pageable pageable);

}
