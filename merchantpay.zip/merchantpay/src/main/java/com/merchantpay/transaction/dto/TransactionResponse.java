package com.merchantpay.transaction.dto;
import com.merchantpay.common.enums.Enums.PaymentChannel;
import com.merchantpay.common.enums.Enums.TransactionStatus;
import com.merchantpay.common.enums.Enums.TransactionType;
import com.merchantpay.transaction.domain.PaymentTransaction;
import lombok.Builder;
import java.math.BigDecimal;
import java.time.Instant;

/**

 * Read model for a {@link PaymentTransaction}.

 */

@Builder

public record TransactionResponse(

        Long txnId,
        Long merchantId,
        Long terminalId,
        Long batchId,
        PaymentChannel paymentChannel,
        TransactionType transactionType,
        BigDecimal amount,
        String currency,
        String cardBin,
        String authorisationCode,
        Instant transactionDateTime,
        TransactionStatus status

) {

    public static TransactionResponse from(PaymentTransaction t) {
        return TransactionResponse.builder()
                .txnId(t.getTxnId())
                .merchantId(t.getMerchantId())
                .terminalId(t.getTerminalId())
                .batchId(t.getBatchId())
                .paymentChannel(t.getPaymentChannel())
                .transactionType(t.getTransactionType())
                .amount(t.getAmount())
                .currency(t.getCurrency())
                .cardBin(t.getCardBin())
                .authorisationCode(t.getAuthorisationCode())
                .transactionDateTime(t.getTransactionDateTime())
                .status(t.getStatus())
                .build();
    }
}
