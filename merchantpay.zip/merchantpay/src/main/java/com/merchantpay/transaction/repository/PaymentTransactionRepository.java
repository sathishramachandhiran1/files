package com.merchantpay.transaction.repository;

import com.merchantpay.common.enums.Enums.TransactionStatus;
import com.merchantpay.transaction.domain.PaymentTransaction;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.Instant;

/**
 * Data access for {@link PaymentTransaction} entities.
 */
public interface PaymentTransactionRepository extends JpaRepository<PaymentTransaction, Long> {

    Page<PaymentTransaction> findByMerchantId(Long merchantId, Pageable pageable);

    Page<PaymentTransaction> findByStatus(TransactionStatus status, Pageable pageable);

    Page<PaymentTransaction> findByMerchantIdAndStatus(Long merchantId, TransactionStatus status, Pageable pageable);

    int countByCardBinAndTransactionDateTimeAfter(String cardBin, Instant fiveMin);

    long countByMerchantId(Long merchantId);

    long countByMerchantIdAndStatus(Long merchantId, TransactionStatus transactionStatus);
}
