package com.merchantpay.security;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Optional;
public final class SecurityUtils {

    private SecurityUtils() {
    }

    public static Optional<AppUserPrincipal> getCurrentPrincipal() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.getPrincipal() instanceof AppUserPrincipal principal) {
            return Optional.of(principal);
        }
        return Optional.empty();
    }

    public static Long getCurrentUserId() {
        return getCurrentPrincipal().map(AppUserPrincipal::getUserId).orElse(null);
    }

    public static Long getCurrentMerchantId() {
        return getCurrentPrincipal().map(AppUserPrincipal::getMerchantId).orElse(null);
    }

    public static boolean isMerchant() {
        return getCurrentPrincipal()
                .map(p -> p.getAuthorities().stream()
                        .anyMatch(a -> a.getAuthority().equals("ROLE_MERCHANT")))
                .orElse(false);
    }
}
