package com.merchantpay.onboarding.dto;

import com.merchantpay.common.enums.Enums.RiskCategory;
import com.merchantpay.common.enums.Enums.SettlementFrequency;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record ApproveApplicationRequest(
        @NotBlank String merchantCode,
        @NotNull RiskCategory riskCategory,
        @NotNull SettlementFrequency settlementFrequency,
        Long feeScheduleId
) {
}
