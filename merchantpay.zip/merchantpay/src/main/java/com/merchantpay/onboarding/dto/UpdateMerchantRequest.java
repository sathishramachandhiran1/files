package com.merchantpay.onboarding.dto;

import com.merchantpay.common.enums.Enums.MerchantStatus;
import com.merchantpay.common.enums.Enums.RiskCategory;
import com.merchantpay.common.enums.Enums.SettlementFrequency;

public record UpdateMerchantRequest(
        RiskCategory riskCategory,
        SettlementFrequency settlementFrequency,
        Long feeScheduleId,
        MerchantStatus status
) {
}
