package com.merchantpay.onboarding.dto;

import com.merchantpay.common.enums.Enums.VerificationStatus;
import jakarta.validation.constraints.NotNull;

public record VerifyDocumentRequest(
        @NotNull VerificationStatus verificationStatus) {
}
