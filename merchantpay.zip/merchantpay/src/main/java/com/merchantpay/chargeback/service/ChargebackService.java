package com.merchantpay.chargeback.service;

import com.merchantpay.chargeback.domain.ChargebackCase;
import com.merchantpay.chargeback.domain.DisputeEvidence;
import com.merchantpay.chargeback.dto.*;
import com.merchantpay.chargeback.repository.ChargebackCaseRepository;
import com.merchantpay.chargeback.repository.DisputeEvidenceRepository;
import com.merchantpay.common.enums.Enums.ChargebackStatus;
import com.merchantpay.common.enums.Enums.EvidenceStatus;
import com.merchantpay.common.enums.Role;
import com.merchantpay.common.exception.BusinessRuleException;
import com.merchantpay.common.exception.ResourceNotFoundException;
import com.merchantpay.iam.domain.User;
import com.merchantpay.iam.repository.UserRepository;
import com.merchantpay.iam.service.AuditService;
import com.merchantpay.onboarding.repository.MerchantRepository;
import com.merchantpay.security.SecurityUtils;
import com.merchantpay.transaction.repository.PaymentTransactionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.Set;
@Service
@RequiredArgsConstructor
@Transactional
public class ChargebackService {

    private static final Set<ChargebackStatus> TERMINAL_STATUSES =
            Set.of(ChargebackStatus.WON, ChargebackStatus.LOST, ChargebackStatus.REVERSED);

    private static final Set<ChargebackStatus> RESOLVABLE_STATUSES =
            Set.of(ChargebackStatus.EVIDENCE_SUBMITTED, ChargebackStatus.DOCUMENTS_REQUESTED);

    private final ChargebackCaseRepository caseRepository;
    private final DisputeEvidenceRepository evidenceRepository;
    private final AuditService auditService;
    private final PaymentTransactionRepository transaction;
    private final MerchantRepository merchant;
    private final UserRepository user;

    // ---------------- Cases ----------------

    public ChargebackCaseResponse createCase(CreateChargebackCaseRequest req) {
        if(merchant.findById(req.merchantId()).isEmpty()){
            throw new ResourceNotFoundException("Merchant with "+req.merchantId()+" doesn't exist");
        }
        if(transaction.findById(req.txnId()).isEmpty()){
            throw new ResourceNotFoundException("Transaction with "+req.txnId()+" doesn't exist");
        }

        LocalDate received = LocalDate.now();
        LocalDate deadline = (req.responseDeadline() != null) ? req.responseDeadline() : received.plusDays(30);

        ChargebackCase chargebackCase = ChargebackCase.builder()
                .txnId(req.txnId())
                .merchantId(req.merchantId())
                .reasonCode(req.reasonCode())
                .claimAmount(req.claimAmount())
                .receivedDate(received)
                .responseDeadline(deadline)
                .status(ChargebackStatus.RECEIVED)
                .build();

        chargebackCase = caseRepository.save(chargebackCase);
        auditService.record(SecurityUtils.getCurrentUserId(), "CHARGEBACK_CASE_CREATED",
                "ChargebackCase", chargebackCase.getCaseId());
        return ChargebackCaseResponse.from(chargebackCase);
    }

    @Transactional(readOnly = true)
    public Page<ChargebackCaseResponse> listCases(Long merchantId, ChargebackStatus status,
                                                   Long assignedAnalystId, Pageable pageable) {
        Page<ChargebackCase> page;

        if (merchantId != null && status != null && assignedAnalystId != null) {
            page = caseRepository.findByMerchantIdAndStatusAndAssignedAnalystId(merchantId, status, assignedAnalystId, pageable);
        } else if (merchantId != null && status != null) {
            page = caseRepository.findByMerchantIdAndStatus(merchantId, status, pageable);
        } else if (merchantId != null && assignedAnalystId != null) {
            page = caseRepository.findByMerchantIdAndAssignedAnalystId(merchantId, assignedAnalystId, pageable);
        } else if (status != null && assignedAnalystId != null) {
            page = caseRepository.findByStatusAndAssignedAnalystId(status, assignedAnalystId, pageable);
        } else if (merchantId != null) {
            page = caseRepository.findByMerchantId(merchantId, pageable);
        } else if (status != null) {
            page = caseRepository.findByStatus(status, pageable);
        } else if (assignedAnalystId != null) {
            page = caseRepository.findByAssignedAnalystId(assignedAnalystId, pageable);
        } else {
            page = caseRepository.findAll(pageable);
        }

        return page.map(ChargebackCaseResponse::from);
    }

    @Transactional(readOnly = true)
    public ChargebackCaseResponse getCase(Long caseId) {
        return ChargebackCaseResponse.from(findCase(caseId));
    }

    public ChargebackCaseResponse requestDocuments(Long caseId) {
        ChargebackCase chargebackCase = findCase(caseId);
        if (chargebackCase.getStatus() != ChargebackStatus.RECEIVED) {
            throw new BusinessRuleException(
                    "Document request is only allowed from RECEIVED status; current status: " + chargebackCase.getStatus());
        }
        chargebackCase.setStatus(ChargebackStatus.DOCUMENTS_REQUESTED);
        chargebackCase = caseRepository.save(chargebackCase);
        auditService.record(SecurityUtils.getCurrentUserId(), "DOCUMENTS_REQUESTED",
                "ChargebackCase", caseId);
        return ChargebackCaseResponse.from(chargebackCase);
    }

    public ChargebackCaseResponse assignCase(Long caseId, AssignCaseRequest req) {

        ChargebackCase chargebackCase = findCase(caseId);
        if (TERMINAL_STATUSES.contains(chargebackCase.getStatus())) {
            throw new BusinessRuleException(
                    "Cannot assign an analyst to a case in terminal status: " + chargebackCase.getStatus());
        }
        User analyst= user.findById(req.analystId())
                .filter(u->u.getRole().equals(Role.DISPUTE_ANALYST))
                .orElseThrow(()->new ResourceNotFoundException("Analyst not Found"));
        chargebackCase.setAssignedAnalystId(req.analystId());
        chargebackCase = caseRepository.save(chargebackCase);
        auditService.record(SecurityUtils.getCurrentUserId(), "CASE_ASSIGNED",
                "ChargebackCase", caseId);
        return ChargebackCaseResponse.from(chargebackCase);
    }

    public ChargebackCaseResponse resolveCase(Long caseId, ResolveCaseRequest req) {
        if (!TERMINAL_STATUSES.contains(req.status())) {
            throw new BusinessRuleException(
                    "Resolution status must be one of WON, LOST, or REVERSED; got: " + req.status());
        }
        ChargebackCase chargebackCase = findCase(caseId);
        if (!RESOLVABLE_STATUSES.contains(chargebackCase.getStatus())) {
            throw new BusinessRuleException(
                    "Case can only be resolved from EVIDENCE_SUBMITTED or DOCUMENTS_REQUESTED; current status: "
                            + chargebackCase.getStatus());
        }
        chargebackCase.setStatus(req.status());
        chargebackCase = caseRepository.save(chargebackCase);
        auditService.record(SecurityUtils.getCurrentUserId(), "CASE_RESOLVED",
                "ChargebackCase", caseId);
        return ChargebackCaseResponse.from(chargebackCase);
    }

    // ---------------- Evidence ----------------

    public DisputeEvidenceResponse submitEvidence(Long caseId, SubmitEvidenceRequest req) {
        ChargebackCase chargebackCase = findCase(caseId);
        if (TERMINAL_STATUSES.contains(chargebackCase.getStatus())) {
            throw new BusinessRuleException(
                    "Cannot submit evidence for a case in terminal status: " + chargebackCase.getStatus());
        }
        if (chargebackCase.getStatus() != ChargebackStatus.RECEIVED
                && chargebackCase.getStatus() != ChargebackStatus.DOCUMENTS_REQUESTED) {
            throw new BusinessRuleException(
                    "Evidence submission is only allowed when case status is RECEIVED or DOCUMENTS_REQUESTED; current status: "
                            + chargebackCase.getStatus());
        }

        DisputeEvidence evidence = DisputeEvidence.builder()
                .caseId(caseId)
                .evidenceType(req.evidenceType())
                .filePath(req.filePath())
                .uploadedDate(LocalDate.now())
                .status(EvidenceStatus.SUBMITTED)
                .build();
        evidence = evidenceRepository.save(evidence);

        // Auto-transition case to EVIDENCE_SUBMITTED after the first piece of evidence
        chargebackCase.setStatus(ChargebackStatus.EVIDENCE_SUBMITTED);
        caseRepository.save(chargebackCase);

        auditService.record(SecurityUtils.getCurrentUserId(), "EVIDENCE_SUBMITTED",
                "DisputeEvidence", evidence.getEvidenceId());
        return DisputeEvidenceResponse.from(evidence);
    }

    @Transactional(readOnly = true)
    public Page<DisputeEvidenceResponse> listEvidence(Long caseId, Pageable pageable) {
        findCase(caseId); // validate case exists
        return evidenceRepository.findByCaseId(caseId, pageable).map(DisputeEvidenceResponse::from);
    }

    public DisputeEvidenceResponse updateEvidenceStatus(Long evidenceId, UpdateEvidenceStatusRequest req) {
        DisputeEvidence evidence = findEvidence(evidenceId);
        evidence.setStatus(req.status());
        evidence = evidenceRepository.save(evidence);
        auditService.record(SecurityUtils.getCurrentUserId(), "EVIDENCE_STATUS_UPDATED",
                "DisputeEvidence", evidenceId);
        return DisputeEvidenceResponse.from(evidence);
    }

    // ---------------- helpers ----------------

    private ChargebackCase findCase(Long caseId) {
        return caseRepository.findById(caseId)
                .orElseThrow(() -> new ResourceNotFoundException("ChargebackCase", caseId));
    }

    private DisputeEvidence findEvidence(Long evidenceId) {
        return evidenceRepository.findById(evidenceId)
                .orElseThrow(() -> new ResourceNotFoundException("DisputeEvidence", evidenceId));
    }
}
