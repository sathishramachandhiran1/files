package com.merchantpay.settlement.service;

import com.merchantpay.common.enums.Enums.MerchantSettlementStatus;
import com.merchantpay.common.enums.Enums.SettlementRunStatus;
import com.merchantpay.common.exception.BusinessRuleException;
import com.merchantpay.common.exception.DuplicateResourceException;
import com.merchantpay.common.exception.ResourceNotFoundException;
import com.merchantpay.iam.service.AuditService;
import com.merchantpay.security.SecurityUtils;
import com.merchantpay.settlement.domain.MerchantSettlement;
import com.merchantpay.settlement.domain.SettlementRun;
import com.merchantpay.settlement.dto.*;
import com.merchantpay.settlement.repository.MerchantSettlementRepository;
import com.merchantpay.settlement.repository.SettlementRunRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
@Service
@RequiredArgsConstructor
@Transactional
public class SettlementService {

    private final SettlementRunRepository settlementRunRepository;
    private final MerchantSettlementRepository merchantSettlementRepository;
    private final AuditService auditService;

    public SettlementRunResponse createSettlementRun(CreateSettlementRunRequest req) {
        LocalDate date = (req.settlementDate() != null) ? req.settlementDate() : LocalDate.now();

        if (settlementRunRepository.existsBySettlementDate(date)) {
            throw new DuplicateResourceException("Settlement already exists for date: " + date);
        }

        SettlementRun run = SettlementRun.builder()
                .settlementDate(date)
                .status(SettlementRunStatus.DRAFT)
                .build();
        run = settlementRunRepository.save(run);
        auditService.record(SecurityUtils.getCurrentUserId(), "SETTLEMENT_RUN_CREATED", "SettlementRun", run.getSettlementId());
        return SettlementRunResponse.from(run);
    }

    @Transactional(readOnly = true)
    public Page<SettlementRunResponse> listSettlementRuns(SettlementRunStatus status, Pageable pageable) {
        Page<SettlementRun> page = (status == null)
                ? settlementRunRepository.findAll(pageable)
                : settlementRunRepository.findByStatus(status, pageable);
        return page.map(SettlementRunResponse::from);
    }

    @Transactional(readOnly = true)
    public SettlementRunResponse getSettlementRun(Long settlementId) {
        return SettlementRunResponse.from(findSettlementRun(settlementId));
    }

    public SettlementRunResponse processSettlementRun(Long settlementId) {
        SettlementRun run = findSettlementRun(settlementId);
        if (run.getStatus() != SettlementRunStatus.DRAFT && run.getStatus() != SettlementRunStatus.PROCESSING) {
            throw new BusinessRuleException(
                    "Settlement run can only be processed from DRAFT or PROCESSING status; current status: " + run.getStatus());
        }

        run.setStatus(SettlementRunStatus.PROCESSING);
        settlementRunRepository.save(run);

        List<MerchantSettlement> lines = merchantSettlementRepository.findBySettlementId(settlementId);

        int count = lines.size();
        BigDecimal totalGross = lines.stream()
                .map(MerchantSettlement::getGrossAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal totalFees = lines.stream()
                .map(ms -> ms.getInterchangeFee().add(ms.getSchemeFee()).add(ms.getAcquirerMarkup()))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal totalNetFunded = lines.stream()
                .map(MerchantSettlement::getNetFunding)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        run.setTotalMerchantsSettled(count);
        run.setTotalGrossAmount(totalGross);
        run.setTotalFees(totalFees);
        run.setTotalNetFunded(totalNetFunded);
        run.setStatus(SettlementRunStatus.COMPLETED);
        run = settlementRunRepository.save(run);

        auditService.record(SecurityUtils.getCurrentUserId(), "SETTLEMENT_RUN_PROCESSED", "SettlementRun", settlementId);
        return SettlementRunResponse.from(run);
    }

    // ---------------- Merchant Settlement Lines ----------------

    public MerchantSettlementResponse addMerchantSettlement(Long settlementId, AddMerchantSettlementRequest req) {
        findSettlementRun(settlementId); // validate run exists

        BigDecimal interchangeFee = nullSafeZero(req.interchangeFee());
        BigDecimal schemeFee = nullSafeZero(req.schemeFee());
        BigDecimal acquirerMarkup = nullSafeZero(req.acquirerMarkup());
        BigDecimal netFunding = req.grossAmount()
                .subtract(interchangeFee.add(schemeFee).add(acquirerMarkup));

        MerchantSettlement ms = MerchantSettlement.builder()
                .settlementId(settlementId)
                .merchantId(req.merchantId())
                .grossAmount(req.grossAmount())
                .interchangeFee(interchangeFee)
                .schemeFee(schemeFee)
                .acquirerMarkup(acquirerMarkup)
                .netFunding(netFunding)
                .fundingBankRef(req.fundingBankRef())
                .status(MerchantSettlementStatus.PENDING)
                .build();
        ms = merchantSettlementRepository.save(ms);
        auditService.record(SecurityUtils.getCurrentUserId(), "MERCHANT_SETTLEMENT_ADDED", "MerchantSettlement", ms.getMerchantSettlementId());
        return MerchantSettlementResponse.from(ms);
    }

    @Transactional(readOnly = true)
    public Page<MerchantSettlementResponse> listLinesByRun(Long settlementId, Pageable pageable) {
        findSettlementRun(settlementId); // validate run exists
        return merchantSettlementRepository.findBySettlementId(settlementId, pageable)
                .map(MerchantSettlementResponse::from);
    }

    @Transactional(readOnly = true)
    public Page<MerchantSettlementResponse> listMerchantSettlements(Long merchantId,
                                                                     MerchantSettlementStatus status,
                                                                     Pageable pageable) {
        Page<MerchantSettlement> page;
        if (merchantId != null && status != null) {
            page = merchantSettlementRepository.findByMerchantIdAndStatus(merchantId, status, pageable);
        } else if (merchantId != null) {
            page = merchantSettlementRepository.findByMerchantId(merchantId, pageable);
        } else if (status != null) {
            page = merchantSettlementRepository.findByStatus(status, pageable);
        } else {
            page = merchantSettlementRepository.findAll(pageable);
        }
        return page.map(MerchantSettlementResponse::from);
    }

    @Transactional(readOnly = true)
    public MerchantSettlementResponse getMerchantSettlement(Long merchantSettlementId) {
        return MerchantSettlementResponse.from(findMerchantSettlement(merchantSettlementId));
    }

    public MerchantSettlementResponse markFunded(Long merchantSettlementId, FundRequest req) {
        MerchantSettlement ms = findMerchantSettlement(merchantSettlementId);
        if (ms.getStatus() != MerchantSettlementStatus.PENDING) {
            throw new BusinessRuleException(
                    "MerchantSettlement can only be funded from PENDING status; current status: " + ms.getStatus());
        }
        if (req.fundingBankRef() == null || req.fundingBankRef().isBlank()) {
            throw new BusinessRuleException("fundingBankRef is required to mark a settlement as funded");
        }
        ms.setFundingBankRef(req.fundingBankRef());
        ms.setStatus(MerchantSettlementStatus.FUNDED);
        ms = merchantSettlementRepository.save(ms);
        auditService.record(SecurityUtils.getCurrentUserId(), "MERCHANT_SETTLEMENT_FUNDED", "MerchantSettlement", merchantSettlementId);
        return MerchantSettlementResponse.from(ms);
    }

    // ---------------- helpers ----------------

    private SettlementRun findSettlementRun(Long settlementId) {
        return settlementRunRepository.findById(settlementId)
                .orElseThrow(() -> new ResourceNotFoundException("SettlementRun", settlementId));
    }

    private MerchantSettlement findMerchantSettlement(Long merchantSettlementId) {
        return merchantSettlementRepository.findById(merchantSettlementId)
                .orElseThrow(() -> new ResourceNotFoundException("MerchantSettlement", merchantSettlementId));
    }

    private BigDecimal nullSafeZero(BigDecimal value) {
        return (value != null) ? value : BigDecimal.ZERO;
    }
}
