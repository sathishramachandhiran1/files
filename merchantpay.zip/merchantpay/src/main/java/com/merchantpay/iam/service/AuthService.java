package com.merchantpay.iam.service;

import com.merchantpay.common.enums.Enums.UserStatus;
import com.merchantpay.common.exception.DuplicateResourceException;
import com.merchantpay.common.exception.ResourceNotFoundException;
import com.merchantpay.iam.domain.User;
import com.merchantpay.iam.dto.*;
import com.merchantpay.iam.repository.UserRepository;
import com.merchantpay.security.AppUserPrincipal;
import com.merchantpay.security.JwtService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtService jwtService;
    private final AuditService auditService;

    @Transactional
    public AuthResponse register(RegisterRequest request) {
        if (userRepository.existsByEmail(request.email())) {
            throw new DuplicateResourceException("Email already registered: " + request.email());
        }

        /*
         * IMPORTANT:
         * merchantId is NOT accepted during registration.
         * For MERCHANT users, merchantId remains null until application approval.
         * After approval, OnboardingService will update user.merchantId automatically.
         */
        User user = User.builder()
                .name(request.name())
                .role(request.role())
                .email(request.email())
                .phone(request.phone())
                .passwordHash(passwordEncoder.encode(request.password()))
                .merchantId(null)
                .status(UserStatus.ACTIVE)
                .build();

        user = userRepository.save(user);

        auditService.record(user.getUserId(), "USER_REGISTERED", "User", user.getUserId());

        return buildAuthResponse(new AppUserPrincipal(user), user);
    }

    @Transactional(readOnly = true)
    public AuthResponse login(LoginRequest request) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.email(), request.password())
        );

        AppUserPrincipal principal = (AppUserPrincipal) authentication.getPrincipal();

        User user = userRepository.findByEmail(principal.getUsername())
                .orElseThrow(() -> new ResourceNotFoundException("User", principal.getUsername()));

        return buildAuthResponse(principal, user);
    }

    private AuthResponse buildAuthResponse(AppUserPrincipal principal, User user) {
        return AuthResponse.builder()
                .accessToken(jwtService.generateAccessToken(principal))
                .tokenType("Bearer")
                .user(UserResponse.from(user))
                .build();
    }
}