package com.merchantpay.fraud.domain;

import com.merchantpay.common.domain.BaseEntity;
import com.merchantpay.common.enums.Enums.FraudFlagStatus;
import com.merchantpay.common.enums.Enums.FraudType;
import com.merchantpay.transaction.domain.PaymentTransaction;
import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

/**
 * Records a fraud flag raised against a transaction or merchant account.
 */
@Entity
@Table(name = "fraud_flag", indexes = {
        @Index(name = "idx_fraud_flag_merchant_id", columnList = "merchant_id"),
        @Index(name = "idx_fraud_flag_txn_id", columnList = "txn_id")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FraudFlag extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "flag_id")
    private Long flagId;

    @Column(name = "txn_id")
    private Long txnId;

    @Column(name = "merchant_id", nullable = false)
    private Long merchantId;

    @Enumerated(EnumType.STRING)
    @Column(name = "fraud_type", nullable = false, length = 32)
    private FraudType fraudType;

    @Column(name = "risk_score")
    private Integer riskScore;

    @Column(name = "flagged_date")
    @Builder.Default
    private Instant flaggedDate = Instant.now();

    @Column(name = "assigned_analyst_id")
    private Long assignedAnalystId;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 24)
    @Builder.Default
    private FraudFlagStatus status = FraudFlagStatus.OPEN;

    @PrePersist
    private void prePersist() {
        if (flaggedDate == null) {
            flaggedDate = Instant.now();
        }
        if (status == null) {
            status = FraudFlagStatus.OPEN;
        }
    }
}
