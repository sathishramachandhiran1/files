package com.merchantpay.fraud.repository;

import com.merchantpay.common.enums.Enums.FraudFlagStatus;
import com.merchantpay.fraud.domain.FraudFlag;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Data access for {@link FraudFlag} records, with flexible filter finders used by the service layer.
 */
public interface FraudFlagRepository extends JpaRepository<FraudFlag, Long> {

    Page<FraudFlag> findByMerchantId(Long merchantId, Pageable pageable);

    Page<FraudFlag> findByStatus(FraudFlagStatus status, Pageable pageable);

    Page<FraudFlag> findByAssignedAnalystId(Long assignedAnalystId, Pageable pageable);

    Page<FraudFlag> findByMerchantIdAndStatus(Long merchantId, FraudFlagStatus status, Pageable pageable);

    Page<FraudFlag> findByMerchantIdAndAssignedAnalystId(Long merchantId, Long assignedAnalystId, Pageable pageable);

    Page<FraudFlag> findByStatusAndAssignedAnalystId(FraudFlagStatus status, Long assignedAnalystId, Pageable pageable);

    Page<FraudFlag> findByMerchantIdAndStatusAndAssignedAnalystId(Long merchantId, FraudFlagStatus status,
                                                                   Long assignedAnalystId, Pageable pageable);

    List<FraudFlag> findByMerchantIdAndStatusIn(Long merchantId, List<FraudFlagStatus> open);
}
