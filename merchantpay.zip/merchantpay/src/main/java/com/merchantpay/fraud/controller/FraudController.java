package com.merchantpay.fraud.controller;

import com.merchantpay.common.enums.Enums.FraudFlagStatus;
import com.merchantpay.common.web.PageResponse;
import com.merchantpay.fraud.dto.*;
import com.merchantpay.fraud.service.FraudService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping
@RequiredArgsConstructor
@Tag(name = "Fraud Monitoring & Risk Management", description = "Fraud flags and merchant risk score management")
public class FraudController {

    private final FraudService fraudService;

    // ---- Fraud Flags ----

    @GetMapping("/fraud-flags")
    @PreAuthorize("hasAnyRole('FRAUD_ANALYST','ADMIN')")
    @Operation(summary = "List fraud flags, optionally filtered by merchantId, status, or assignedAnalystId")
    public PageResponse<FraudFlagResponse> listFlags(
            @RequestParam(required = false) Long merchantId,
            @RequestParam(required = false) FraudFlagStatus status,
            @RequestParam(required = false) Long assignedAnalystId,
            Pageable pageable) {
        return PageResponse.from(fraudService.listFlags(merchantId, status, assignedAnalystId, pageable), f -> f);
    }

    @GetMapping("/fraud-flags/{flagId}")
    @PreAuthorize("hasAnyRole('FRAUD_ANALYST','ADMIN')")
    @Operation(summary = "Get a fraud flag by id")
    public FraudFlagResponse getFlag(@PathVariable Long flagId) {
        return fraudService.getFlag(flagId);
    }

    @PostMapping("/fraud-flags/{flagId}/investigate")
    @PreAuthorize("hasAnyRole('FRAUD_ANALYST','ADMIN')")
    @Operation(summary = "Transition a fraud flag from OPEN to UNDER_INVESTIGATION")
    public FraudFlagResponse investigate(@PathVariable Long flagId) {
        return fraudService.investigate(flagId);
    }

    @PostMapping("/fraud-flags/{flagId}/assign")
    @PreAuthorize("hasAnyRole('FRAUD_ANALYST','ADMIN')")
    @Operation(summary = "Assign a fraud flag to an analyst")
    public FraudFlagResponse assign(@PathVariable Long flagId,
                                    @Valid @RequestBody AssignFlagRequest req) {
        return fraudService.assign(flagId, req);
    }

    @PostMapping("/fraud-flags/{flagId}/resolve")
    @PreAuthorize("hasAnyRole('FRAUD_ANALYST','ADMIN')")
    @Operation(summary = "Resolve a fraud flag as CLEARED, CONFIRMED, or REPORTED")
    public FraudFlagResponse resolve(@PathVariable Long flagId,
                                     @Valid @RequestBody ResolveFlagRequest req) {
        return fraudService.resolve(flagId, req);
    }

    // ---- Merchant Risk Scores ----

    @GetMapping("/merchants/{merchantId}/risk-scores")
    @PreAuthorize("hasAnyRole('FRAUD_ANALYST','ADMIN')")
    @Operation(summary = "List all risk scores (history) for a merchant")
    public PageResponse<MerchantRiskScoreResponse> listRiskScores(
            @PathVariable Long merchantId,
            Pageable pageable) {
        return PageResponse.from(fraudService.listRiskScores(merchantId, pageable), s -> s);
    }

    @GetMapping("/merchants/{merchantId}/risk-scores/current")
    @PreAuthorize("hasAnyRole('FRAUD_ANALYST','ADMIN')")
    @Operation(summary = "Get the current risk score for a merchant (404 if none exists)")
    public MerchantRiskScoreResponse getCurrentRiskScore(@PathVariable Long merchantId) {
        return fraudService.getCurrentRiskScore(merchantId);
    }
}
